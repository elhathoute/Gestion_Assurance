-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 16 juin 2021 à 13:56
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `morit_assur`
--

-- --------------------------------------------------------

--
-- Structure de la table `affaires`
--

DROP TABLE IF EXISTS `affaires`;
CREATE TABLE IF NOT EXISTS `affaires` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datea` date NOT NULL,
  `timea` time NOT NULL,
  `compagnie` int(11) NOT NULL,
  `police` varchar(100) NOT NULL,
  `numAttest` varchar(300) NOT NULL,
  `type` int(11) NOT NULL,
  `ferme` int(11) NOT NULL,
  `client` int(11) NOT NULL,
  `risque` int(11) NOT NULL,
  `production` decimal(14,2) NOT NULL,
  `nbrFractions` int(11) NOT NULL,
  `duree` int(11) NOT NULL,
  `datei` date NOT NULL,
  `datef` date NOT NULL,
  `solde` decimal(14,2) NOT NULL,
  `obs` varchar(1000) NOT NULL,
  `etat` int(11) NOT NULL,
  `op` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cnt_1` (`client`),
  KEY `cnt_2` (`compagnie`),
  KEY `cnt_3` (`risque`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `affaires`
--

INSERT INTO `affaires` (`id`, `datea`, `timea`, `compagnie`, `police`, `numAttest`, `type`, `ferme`, `client`, `risque`, `production`, `nbrFractions`, `duree`, `datei`, `datef`, `solde`, `obs`, `etat`, `op`) VALUES
(10, '2021-05-19', '23:33:00', 4, 'M852', '674', 1, 1, 5, 1, '20000.00', 2, 1, '2021-05-19', '2021-06-18', '20000.00', '1', 1, 'radwan7@gmail.com'),
(19, '2021-05-21', '13:45:00', 5, 'h54', '1750', 1, 1, 6, 3, '4500.00', 2, 1, '2021-05-21', '2021-06-20', '4500.00', '1', 1, 'radwan7@gmail.com'),
(20, '2021-05-21', '14:07:00', 4, 'ml12', '6040', 1, 1, 6, 1, '6200.00', 1, 1, '2021-05-21', '2021-06-20', '6200.00', '1', 1, 'radwan7@gmail.com'),
(21, '2021-05-30', '00:54:00', 4, 'jk98652', '3930', 0, 0, 11, 2, '4512.99', 2, 12, '2021-05-28', '2022-05-23', '2256.49', '545', 0, 'radwan7@gmail.com'),
(23, '2021-05-21', '23:32:00', 4, '52', '7752', 1, 1, 5, 1, '85421.00', 4, 1, '2021-05-21', '2021-06-20', '85421.00', '1', 1, 'radwan7@gmail.com'),
(24, '2021-05-21', '23:48:00', 5, '96', '8573', 0, 1, 6, 1, '845.96', 2, 1, '2021-05-21', '2021-11-17', '845.96', '99', -1, 'radwan7@gmail.com'),
(38, '2021-05-23', '14:46:00', 6, 'kk74', '1840', 1, 1, 4, 1, '8500.00', 3, 3, '2021-05-23', '2021-08-21', '5666.67', '1', 1, 'radwan7@gmail.com'),
(40, '2021-05-23', '18:56:00', 4, 'vv4', '8031', 1, 1, 5, 1, '6660.00', 3, 1, '2021-05-23', '2021-06-22', '4440.00', '1', 1, 'radwan7@gmail.com'),
(44, '2021-05-24', '14:49:00', 5, 'ml54', '7357', 1, 1, 6, 1, '6500.00', 2, 1, '2021-05-24', '2021-06-23', '6500.00', 'mm', 1, 'radwan7@gmail.com'),
(45, '2021-05-24', '15:16:00', 6, 'qs32', '9510', 0, 1, 11, 5, '8925.78', 2, 6, '2021-05-26', '2021-11-22', '8825.78', 'tbien', 1, 'radwan7@gmail.com'),
(49, '2021-05-25', '15:41:00', 6, 'zp23', 'yxf138', 1, 1, 6, 1, '6542.00', 2, 1, '2021-04-19', '2021-05-19', '6542.00', '1', 1, 'radwan7@gmail.com'),
(50, '2021-05-25', '15:42:00', 4, 'qw28', 'mvx134', 1, 1, 5, 1, '6500.00', 1, 1, '2021-04-15', '2021-05-15', '6500.00', '1', 1, 'radwan7@gmail.com'),
(51, '2021-05-25', '15:43:00', 5, 'fd19', 'zqg267', 1, 1, 5, 1, '4150.00', 1, 1, '2021-04-24', '2021-05-24', '4150.00', '', 1, 'radwan7@gmail.com'),
(52, '2021-05-25', '16:04:00', 5, 'cg12', 'kpm789', 1, 1, 11, 1, '9600.00', 2, 1, '2021-04-23', '2021-05-23', '4800.00', 'obs1\r\n', 1, 'radwan7@gmail.com'),
(56, '2021-05-25', '16:28:00', 6, 'it38', 'lbr135', 1, 1, 11, 1, '9742.00', 1, 1, '2021-05-26', '2021-06-25', '9742.00', '1', 1, 'radwan7@gmail.com'),
(57, '2021-05-25', '16:28:00', 6, 'wv28', 'xzl168', 1, 1, 12, 1, '8999.00', 1, 1, '2021-05-24', '2021-06-23', '6000.00', '1', 1, 'radwan7@gmail.com'),
(59, '2021-05-25', '19:36:00', 5, 'jv12', 'pgu147', 1, 1, 5, 1, '5412.00', 2, 1, '2021-04-18', '2021-05-18', '2706.00', 'bien', 1, 'radwan7@gmail.com'),
(60, '2021-05-25', '19:37:00', 6, 'as06', 'ohn359', 1, 1, 5, 1, '2540.00', 1, 1, '2021-04-17', '2021-05-17', '300.00', '', 1, 'radwan7@gmail.com'),
(72, '2021-05-26', '19:43:00', 5, 'kb18', 'zdc267', 1, 1, 10, 1, '4000.00', 1, 1, '2021-05-26', '2021-06-25', '0.00', '1', 1, 'radwan7@gmail.com'),
(74, '2021-05-26', '20:08:00', 4, 'lkyi3468', 'vqif1367', 1, 1, 5, 1, '8451.00', 1, 1, '2021-05-26', '2021-06-25', '8451.00', '1', 1, 'radwan7@gmail.com'),
(75, '2021-05-26', '20:11:00', 6, 'KMNF0489', 'LCVS0478', 1, 1, 4, 1, '8590.00', 1, 1, '2021-05-26', '2021-06-25', '8590.00', '1', 1, 'radwan7@gmail.com'),
(77, '2021-05-27', '00:20:00', 4, 'MUZD1234', 'GFRO2579', 1, 1, 6, 1, '65847.88', 1, 1, '2021-05-26', '2021-06-25', '65847.88', '1', 1, 'radwan7@gmail.com'),
(78, '2021-05-27', '15:20:00', 4, 'RXEV3457', 'MCQX0257', 1, 1, 6, 1, '4658.33', 1, 1, '2021-05-27', '2021-06-26', '4658.33', '', 1, 'radwan7@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(500) COLLATE utf8_bin NOT NULL,
  `cin` varchar(100) COLLATE utf8_bin NOT NULL,
  `contact` varchar(500) COLLATE utf8_bin NOT NULL,
  `adresse` varchar(500) COLLATE utf8_bin NOT NULL,
  `ville` varchar(50) COLLATE utf8_bin NOT NULL,
  `cp` varchar(50) COLLATE utf8_bin NOT NULL,
  `tel` varchar(50) COLLATE utf8_bin NOT NULL,
  `fax` varchar(50) COLLATE utf8_bin NOT NULL,
  `ice` varchar(50) COLLATE utf8_bin NOT NULL,
  `mail` varchar(50) COLLATE utf8_bin NOT NULL,
  `activite` varchar(300) COLLATE utf8_bin NOT NULL,
  `obs` varchar(500) COLLATE utf8_bin NOT NULL,
  `pays` varchar(50) COLLATE utf8_bin NOT NULL,
  `mandataire` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id`, `nom`, `cin`, `contact`, `adresse`, `ville`, `cp`, `tel`, `fax`, `ice`, `mail`, `activite`, `obs`, `pays`, `mandataire`) VALUES
(4, 'radwan msaad ', 'Y54219', '   ', 'marrakech ', 'marrakech ', '40000', '0767276367', '', '', 'radwan7@gmail.com', '', '', 'Maroc', 5),
(5, 'said', 'E542112', ' ', '', '', '', '0764651212', '', '', '', '', '', '', 7),
(6, 'ahmed', 'U8452121', '', '', '', '', '075241852', '', '', '', '', '', '', 0),
(10, 'ahmad si', 'U121646', '     ', 'marrakech  ', 'marrakech  ', '40000', '', '', '', 'ahmed3@gmail.com', '', '', '    ', 0),
(11, 'anas ', 'Q845127855', '    ', 'fes', 'fes ', '30000', '', '', '', 'anas@gmail.com', '', '', 'Arabie Saoudite', 4),
(12, 'jawad', 'H541114', ' ', '', '', '', '068525445', '', '', 'jawad@gmail.com', '', '', 'Maroc', 5),
(13, 'kamal', 'ZE2125454', '', '', '', '', '079652212', '', '', '', '', '', '', 0),
(14, 'samir', 'Y8774512', '', 'marrakech', 'marrakech', '123456789', '+212984545212', '', '', 'samir@gmail.com', '', '', '', 5),
(15, 'radwan', 'Y123456', '', '', '', '', '', '', '', 'radwan@gmail.com', '', '', '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `compagnies`
--

DROP TABLE IF EXISTS `compagnies`;
CREATE TABLE IF NOT EXISTS `compagnies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(500) NOT NULL,
  `adresse` varchar(1000) NOT NULL,
  `cp` varchar(50) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `fax` varchar(50) NOT NULL,
  `mail` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `compagnies`
--

INSERT INTO `compagnies` (`id`, `nom`, `adresse`, `cp`, `ville`, `tel`, `fax`, `mail`) VALUES
(4, 'saham', 'rabat', '20000', 'rabat', '0751215452', '056432122', 'saham@gmail.com'),
(5, 'wafa', 'casa', '30000', 'casa', '069874544', '0531323', 'wafa@gmail.com'),
(6, 'aliaz', 'rabat', '20000', 'rabat', '065874784', '0574854574', 'aliaz@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `fractions`
--

DROP TABLE IF EXISTS `fractions`;
CREATE TABLE IF NOT EXISTS `fractions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `affaire` int(11) NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `date_effet` date NOT NULL,
  `date_reg` date DEFAULT NULL,
  `solde` decimal(10,2) NOT NULL,
  `obs` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cnt_20` (`affaire`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `fractions`
--

INSERT INTO `fractions` (`id`, `affaire`, `montant`, `date_effet`, `date_reg`, `solde`, `obs`) VALUES
(97, 45, '4462.89', '2021-05-26', '2021-05-26', '4362.89', NULL),
(98, 45, '4462.89', '2021-08-24', '2021-08-24', '4462.89', NULL),
(124, 40, '2220.00', '2021-05-23', '2021-05-23', '0.00', NULL),
(125, 40, '2220.00', '2021-06-02', '2021-06-02', '2220.00', NULL),
(126, 40, '2220.00', '2021-06-12', '2021-06-12', '2220.00', NULL),
(127, 38, '2833.33', '2021-05-23', '2021-05-23', '0.00', NULL),
(128, 38, '2833.33', '2021-06-22', '2021-06-22', '2833.33', NULL),
(129, 38, '2833.33', '2021-07-22', '2021-07-22', '2833.33', NULL),
(132, 21, '2256.50', '2021-05-28', '2021-05-28', '0.00', NULL),
(133, 21, '2256.50', '2021-11-24', '2021-11-24', '2256.50', NULL),
(141, 52, '4800.00', '2021-04-23', '2021-04-23', '0.00', NULL),
(142, 52, '4800.00', '2021-05-08', '2021-05-08', '4800.00', NULL),
(147, 57, '8999.00', '2021-05-24', '2021-05-24', '6000.00', NULL),
(150, 59, '2706.00', '2021-04-18', '2021-04-18', '0.00', NULL),
(151, 59, '2706.00', '2021-05-03', '2021-05-03', '2706.00', NULL),
(152, 60, '2540.00', '2021-04-17', '2021-05-26', '400.00', NULL),
(157, 72, '4000.00', '2021-05-26', '2021-05-26', '0.00', NULL),
(160, 74, '8451.00', '2021-05-26', NULL, '8451.00', NULL),
(161, 75, '8590.00', '2021-05-26', NULL, '8590.00', NULL),
(162, 56, '9742.00', '2021-05-26', NULL, '9742.00', NULL),
(166, 49, '3271.00', '2021-04-19', NULL, '3271.00', NULL),
(167, 49, '3271.00', '2021-05-04', NULL, '3271.00', NULL),
(168, 51, '4150.00', '2021-04-24', NULL, '4150.00', NULL),
(169, 44, '3250.00', '2021-05-24', NULL, '3250.00', NULL),
(170, 44, '3250.00', '2021-06-08', NULL, '3250.00', NULL),
(171, 24, '422.98', '2021-05-21', NULL, '422.98', NULL),
(172, 24, '422.98', '2021-06-05', NULL, '422.98', NULL),
(173, 23, '21355.25', '2021-05-21', NULL, '21355.25', NULL),
(174, 23, '21355.25', '2021-05-28', NULL, '21355.25', NULL),
(175, 23, '21355.25', '2021-06-04', NULL, '21355.25', NULL),
(176, 23, '21355.25', '2021-06-11', NULL, '21355.25', NULL),
(177, 20, '6200.00', '2021-05-21', NULL, '6200.00', NULL),
(178, 19, '2250.00', '2021-05-21', NULL, '2250.00', NULL),
(179, 19, '2250.00', '2021-06-05', NULL, '2250.00', NULL),
(180, 10, '10000.00', '2021-05-19', NULL, '10000.00', ''),
(181, 10, '10000.00', '2021-06-03', NULL, '10000.00', NULL),
(182, 50, '6500.00', '2021-04-15', NULL, '6500.00', 'good'),
(185, 77, '65847.88', '2021-05-26', NULL, '65847.88', 'bienll'),
(189, 78, '4658.33', '2021-05-27', NULL, '4658.33', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `mandataires`
--

DROP TABLE IF EXISTS `mandataires`;
CREATE TABLE IF NOT EXISTS `mandataires` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(500) COLLATE utf8_bin NOT NULL,
  `cin` varchar(100) COLLATE utf8_bin NOT NULL,
  `adresse` varchar(500) COLLATE utf8_bin NOT NULL,
  `ville` varchar(50) COLLATE utf8_bin NOT NULL,
  `cp` varchar(50) COLLATE utf8_bin NOT NULL,
  `tel` varchar(50) COLLATE utf8_bin NOT NULL,
  `ice` varchar(50) COLLATE utf8_bin NOT NULL,
  `mail` varchar(50) COLLATE utf8_bin NOT NULL,
  `activite` varchar(300) COLLATE utf8_bin NOT NULL,
  `obs` varchar(500) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `mandataires`
--

INSERT INTO `mandataires` (`id`, `nom`, `cin`, `adresse`, `ville`, `cp`, `tel`, `ice`, `mail`, `activite`, `obs`) VALUES
(4, 'aziz', 'R185254', 'marrakech ', 'fes ', '30000', '0667276388', '', 'aziz@gmail.com', '', ''),
(5, 'radwan msaad ', 'O546541', 'marrakech ', 'marrakech ', '40000', '0767276367', '', 'radwan7@gmail.com', '', ''),
(6, 'RADWAN ', 'P852741', 'marrakech ', 'marrakech ', '40000', '0654548751', '', 'radwan3@gmail.com', '', ''),
(7, 'amin', 'T874124', '', 'casa', '20000', '0785214578', '', '', '', ''),
(8, 'farid', 'R123456', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `reglement`
--

DROP TABLE IF EXISTS `reglement`;
CREATE TABLE IF NOT EXISTS `reglement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fraction` int(11) NOT NULL,
  `montant` decimal(14,2) NOT NULL,
  `datea` date NOT NULL,
  `mode` int(1) NOT NULL,
  `ref` varchar(500) NOT NULL,
  `validation` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cnt_21` (`fraction`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reglement`
--

INSERT INTO `reglement` (`id`, `fraction`, `montant`, `datea`, `mode`, `ref`, `validation`) VALUES
(60, 127, '2833.33', '2021-05-25', 1, 'uw47', 1),
(61, 124, '2220.00', '2021-05-25', 1, 'yd24', 1),
(62, 132, '2256.50', '2021-05-25', 1, 'xl02', 1),
(66, 97, '100.00', '2021-05-25', 1, 'xf68', 1),
(68, 150, '2706.00', '2021-05-25', 1, 'tr09', 1),
(70, 141, '4800.00', '2021-05-25', 1, 'eu05', 1),
(71, 147, '2999.00', '2021-05-25', 1, 'ep02', 1),
(72, 152, '1540.00', '2021-05-26', 1, 'xn57', 1),
(73, 152, '500.00', '2021-05-26', 1, 'qu24', 1),
(75, 152, '100.00', '2021-05-26', 1, 'xe35', 1),
(76, 157, '4000.00', '2021-05-26', 1, 'mz09', 1);

-- --------------------------------------------------------

--
-- Structure de la table `risque`
--

DROP TABLE IF EXISTS `risque`;
CREATE TABLE IF NOT EXISTS `risque` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `marque` varchar(500) NOT NULL,
  `matricule` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `risque`
--

INSERT INTO `risque` (`id`, `marque`, `matricule`) VALUES
(1, 'TOYOTA', 'ab-123458  '),
(2, 'BMW', 'ty665646'),
(3, 'jeep', 'bn-8754121'),
(5, 'BMW ', 'bv52199'),
(6, 'jeep', 'nb545'),
(7, 'audi', 'mn248'),
(8, 'Audi', 'kl1234'),
(14, 'Audi', 'm12345');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `type` int(2) NOT NULL,
  `etat` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `login`, `pwd`, `email`, `type`, `etat`) VALUES
(4, 'radwan', '123.', 'radwan@gmail.com', 1, 1),
(5, 'said', '1234', 'said@gmail.com', 0, 1),
(6, 'amin', '1234', 'amin1@gmail.com', 1, 1),
(7, 'ahmed', '444', 'Ahmed33@gmail.com', 0, 0),
(8, 'yassin', '6820', 'radwanhnino21@gmail.com', 0, 1),
(24, 'farid', '987654', 'farid@gmail.com', 0, 0);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `affaires`
--
ALTER TABLE `affaires`
  ADD CONSTRAINT `cnt_1` FOREIGN KEY (`client`) REFERENCES `clients` (`id`),
  ADD CONSTRAINT `cnt_2` FOREIGN KEY (`compagnie`) REFERENCES `compagnies` (`id`),
  ADD CONSTRAINT `cnt_3` FOREIGN KEY (`risque`) REFERENCES `risque` (`id`);

--
-- Contraintes pour la table `fractions`
--
ALTER TABLE `fractions`
  ADD CONSTRAINT `cnt_20` FOREIGN KEY (`affaire`) REFERENCES `affaires` (`id`);

--
-- Contraintes pour la table `reglement`
--
ALTER TABLE `reglement`
  ADD CONSTRAINT `cnt_21` FOREIGN KEY (`fraction`) REFERENCES `fractions` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
