<?php
 require_once("identifier.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Etat</title>
	<?php require("styleLinks.php");?>
</head>
<body>
	<?php
     include("header.php");
	?>
<div class="container">
	<div class="util">
	<div class="card">
		<div class="card-header bg-success text-white">Rechercher des etats...</div>
	    <div class="card-body">
	    	Le contenu du paneau
	    </div>
	</div>

	<div class="card">
		<div class="card-header bg-primary text-white">
		List desetats</div>
	    <div class="card-body">
	    	Le tableau des etats
	    </div>
	</div>
	</div>
</div>

<?php
     include("footer.php");
	?>
</body>
</html>