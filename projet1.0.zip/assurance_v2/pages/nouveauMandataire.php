<?php
require_once("identifier.php");
?>
<!DOCTYPE HTML>
<html>
<head>

  <meta charset="utf-8">
  <title>Nouveau Mandataire</title>
 <?php require("styleLinks.php");?>

</head>
<body>

 <?php 
 require_once("identifier.php");

 include("header.php"); ?>


 <div class="container  col-lg-5 col-md-8">



   <div class="card  margetop60"> 

    <div class="card-header bg-primary ">Saisir les données du mandataire</div>
    
    <div class="card-body text-info bg-light">


      <form method="post" action="insertMandataires.php" class="form">
       <div class="form-group ">
         <label for="nom">NOM:
         <input type="text"minlength="3" maxlength="30"autocomplete="off" pattern="^[a-zA-Z\s_]{3,}$" 
         name="nom" required 
         class="form-control "/></label>

         <label for="cin">CIN:
         <input type="text"
         name="cin" required minlength="5" maxlength="10" autocomplete="off" pattern="^([a-zA-Z0-9]){5,10}" 
         class="form-control"/></label>

         <label for="adresse">ADRESSE:
         <input type="text"minlength="3" maxlength="500" autocomplete="off"pattern="([\w\s-]){3,}" 
         name="adresse"    
         class="form-control"/></label>

         <label for="ville">VILLE:
         <input type="text"minlength="3" maxlength="50" autocomplete="off"pattern="^([a-zA-Z_ \s -]){3,}$"
         name="ville"     
         class="form-control"/></label>
         <label for="cp">CP:
         <input type="text"minlength="3" maxlength="20"pattern="^([\d]){3,}"
         name="cp"      
         class="form-control"/></label>
         <label for="tel">TEL:
         <input type="text"minlength="9" maxlength="15" pattern="^(0|\+([0-9]){2,3})([0-9]){8,9}$" 
         name="tel"     
         class="form-control"/></label>
         <label for="ice">ICE:
         <input type="text"minlength="3" maxlength="50"
         name="ice" pattern="^([a-zA-Z0-9]){3,}" 
         class="form-control"/></label>
         <label for="mail">EMAIL:
         <input type="text"minlength="11" maxlength="50" pattern="^([a-zA-Z]){1}([\w.])*(@gmail\.com){1}$" 
         name="mail"      
         class="form-control"/></label>
         <label for="activite">ACTIVITE:
         <input type="text "minlength="3" pattern="^([a-zA-Z\s_-]){3,}"
         name="activite"     
         class="form-control"/></label>
         <label for="ops">OBS:
         <input type="text"minlength="3"pattern="^([a-zA-Z]){3,}([\w\s:_])*"
         name="obs"       
         placeholder="observation" 
         class="form-control"/></label>




      </div>


      <div class="form-group col-md-8">
        <button type="reset" name="reset" class="btn btn-danger">
          <span class="fa fa-remove"></span> 
          reset
        </button>
        <button type="submit" name="save" class="btn btn-success" >
          <span class="fa fa-save"></span> 
          Save
        </button>
        &nbsp &nbsp
      <a href="javaScript:history.back()" id="rt">retour </a>
      </div>
    </form>
  </div>
</div>

</div>


</body>

<footer>

  <?php
  include("footer.php");
  ?>
</footer>

</html> 