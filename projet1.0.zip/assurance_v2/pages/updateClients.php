
<?php
require_once("identifier.php");

require_once('connexiondb.php');

 $id=isset($_POST['id'])?$_POST['id']:0;
 $nom=isset($_POST['nom'])?$_POST['nom']:"";
 $cin=isset($_POST['cin'])?$_POST['cin']:"";
 $contact=isset($_POST['contact'])?$_POST['contact']:"";
 $adresse=isset($_POST['adresse'])?$_POST['adresse']:"";
 $ville=isset($_POST['ville'])?$_POST['ville']:"";
 $cp=isset($_POST['cp'])?$_POST['cp']:"";
 $tel=isset($_POST['tel'])?$_POST['tel']:"";
 $fax=isset($_POST['fax'])?$_POST['fax']:"";
 $ice=isset($_POST['ice'])?$_POST['ice']:"";
 $mail=isset($_POST['mail'])?$_POST['mail']:"";
 $activite=isset($_POST['activite'])?$_POST['activite']:"";
 $obs=isset($_POST['obs'])?$_POST['obs']:"";
 $pays=isset($_POST['pays'])?$_POST['pays']:"";
 $mandataire=isset($_POST['mandataire'])?$_POST['mandataire']:0;
   
 $requete="update clients set nom='$nom',cin='$cin',contact=' $contact',adresse='$adresse',
 ville='$ville',cp='$cp',tel='$tel',fax='$fax',ice='$ice',mail='$mail',activite='$activite',obs='$obs',pays='$pays', mandataire='$mandataire' where id=$id ";


 $resultat=mysqli_query($conn,$requete);

 header('location:clients.php');
?>