<?php
require_once("identifier.php");
require_once('myfunction.php');
require_once('connexiondb.php');

 $marque=isset($_POST['marque'])?$_POST['marque']:"";
 $matricule=isset($_POST['matricule'])?$_POST['matricule']:"";
 if(recherche_par_matricule('risque',$matricule))
    echo '<span class="alert alert-danger">D&eacute;sol&eacute; le matricule d&eacute;ja existe!</span>';
else {
 $requete=" insert into risque (marque,matricule)
 values ('$marque','$matricule')";
 $resultat=mysqli_query($conn,$requete);

echo'<script>window.location.href="vehicules.php"</script>';

}
?>