<?php
    require_once("identifier.php");

        require_once("connexiondb.php");

        
       $size=isset($_GET['size'] ) ?$_GET['size']: 20;     //nbr limite qui affiche dans la page
        $page=isset($_GET['page'] ) ?$_GET['page']: 1;
        $offset= ($page-1)*$size ;  //nbr de sauter
//récuperer une parametre envoyer par la methode GET
    $matricule=strtoupper(isset($_GET['matricule'])?$_GET['matricule']:'');
      $requet = "SELECT * FROM risque  where UPPER(matricule) like '$matricule%'
       order by id desc limit $size 
      offset $offset";
      $requetCount="SELECT count(*) countR from risque where UPPER(matricule) like '$matricule%'";
      //la fct query() pour execut la requet SELECT
     
    
        $resultatRisque = mysqli_query( $conn,$requet) ;  
        $resultatCount =mysqli_query( $conn,$requetCount) ;
        $tabCount=  mysqli_fetch_array($resultatCount) ;
       
        $nbrRisque= $tabCount['countR'];
        $rest= $nbrRisque%$size;  //rest de la division 
         if($rest===0)
          $nbrPage=$nbrRisque/ $size;
          else
          $nbrPage= floor($nbrRisque / $size) +1; //la partie reel plus 1
        
     
      ?>
 

<!DOCTYPE HTML>
 <html>
    <head>

      <meta charset="utf-8">
      <title>Gestion des Risques</title>
     <?php require("styleLinks.php");?>
    </head>
       <body>
           

           <?php
            include("header.php");
             ?>
        <!-- intégrer notre panneau aux milieu de la page !-->
         <div class="container col-lg-5 col-md-10 col-sm-10">
        <!-- panneau de recherche-->  
            <div class="card  margetop60"> 
       <!-- intégrer la partie de recherche !-->
    
            <div class="card-header bg-success">
            
               Rechercher et Ajouter des risques
             </div>
        <!--intégrer le contenu de recherche !-->
              <div class="card-body text-info bg-light">
                <form method="get" action="vehicules.php" class="form-inline">
                 <div class="form-group">
              
                  <input type="text" 
                   name="matricule" id="matricule"
                    placeholder="Taper un matricule" 
                    class="form-control" autocomplete="off"
                    value="<?php echo $matricule ?>">
                </div>
                &nbsp &nbsp 
                  
                        <a method="post" href="nouvelleVehicule.php ">
                            Ajouter un Risque <i class="fa fa-plus"></i>
                        </a>
                        
                </form>
             </div>
          </div>
     <!--------------------------------------------------------- -->

        <!-- panneau du contenu de l'interface-->
       
             <div class="card  "> 
      
            <div class="card-header bg-primary">Liste des risques  [<?php echo $nbrRisque ?>  Risques] </div>
            
              <div   class="card-body text-info bg-light">
                <div id="risque1">
                <table class="table table-striped table-bordered table-responsive tb ">
                  <thead >
                   <tr>
                    <th>Id [<?php echo $nbrRisque ?>]</th> 
                    <th>Marque</th>
                    <th>Matricule</th>  
                    <th>Action</th>
                                   
                   </tr>
                  </thead>
                  <tbody >

                    <?php while($risque=mysqli_fetch_assoc($resultatRisque)) { 

                     $idR=$risque['id'];
                     $req="SELECT * from affaires where risque=$idR";
                     $res=mysqli_query($conn,$req);
                     $bgClr=mysqli_num_rows($res)>0?'bg-danger':'';
                     $clr=mysqli_num_rows($res)>0?'text-white':''; 

                      ?>
                       
                          <tr class="<?php echo $bgClr.' '.$clr;  ?>">
                            <td> <?php echo $risque['id'] ?> </td>
                            <td> <?php echo $risque['marque'] ?> </td>
                            <td> <?php echo $risque['matricule'] ?> </td>
                          
                            <td>
                            <a  href="editerVehicule.php?id=<?php echo $risque['id'] ?>" > <span class="fa fa-edit"></span></a> 
                              &nbsp
                              <?php if($bgClr!='bg-danger'){ ?>
                         <a onclick="return confirm('vous etes sur de supp?')"
                        href="supprimerVehicule.php?id=<?php echo $risque['id'] ?>" >  <span class="fa fa-trash"></span></a>
                        <?php  } ?>
                           </td>
                          </tr>
                          <?php  } ?>

                  </tbody>
                </table>
                </div>
                    <div >
                       <ul class="pagination ">
                        <?php
                        for($i=1;$i<=$nbrPage;$i++){ ?>
                          
                         <li class="<?php if($i == $page) echo'active' ?> page-item"> <a  class="page-link"href="vehicules.php?page=<?php echo $i;?>">  <?php echo $i;?>  </a> </li> 

                       <?php   } ?>
                              
                        </ul>
                    </div>
                   <a href="javaScript:history.back()" id="rt">retour </a>
               </div>
           </div>
     </div>
  
 </body>
       


<footer id="affF">
  

<?php
      include("footer.php");
   ?>
</footer>


 </html>