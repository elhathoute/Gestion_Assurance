<?php  

 require_once("identifier.php");

require_once('connexiondb.php');

 $nom=isset($_POST['nom'])?$_POST['nom']:"";
 $adresse=isset($_POST['adresse'])?$_POST['adresse']:"";
 $cp=isset($_POST['cp'])?$_POST['cp']:"";
 $ville=isset($_POST['ville'])?$_POST['ville']:"";
 $tel=isset($_POST['tel'])?$_POST['tel']:"";
 $fax=isset($_POST['fax'])?$_POST['fax']:"";
 $mail=isset($_POST['mail'])?$_POST['mail']:"";
  $sql="INSERT INTO compagnies(nom,adresse,cp,ville,tel,fax,mail) values('$nom','$adresse','$cp','$ville','$tel','$fax','$mail')";

$res=mysqli_query($conn,$sql);
if($res){
	echo"<span class='alert alert-success'>donn&eacute;es inser&eacute;es.</span>";
     echo '<script> setTimeout(function(){
        window.location.href="compagnie.php?"},1000); </script>';
}
else {

	echo"erreur";
}
  
?>