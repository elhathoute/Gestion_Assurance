<?php
 require_once("identifier.php");
require_once('connexiondb.php');
 $id=isset($_GET['id'])?$_GET['id']:0;
 $obs=isset($_GET['obs'])?$_GET['obs']:0;
 $req="UPDATE affaires set obs='$obs' where id=$id";
 $res=mysqli_query($conn,$req);
 if($res)
 	echo 'les donnees sont modifiees.';
 else echo 'erreur '.mysqli_error($conn);
 header("location:renouvellement.php");
