<?php
 require_once("identifier.php");
  
require_once('connexiondb.php');
 $id=isset($_POST['id'])?$_POST['id']:0;
 $idA=isset($_POST['affaire'])?$_POST['affaire']:0;
 $montant=isset($_POST['montant'])?$_POST['montant']:"";
 $solde=isset($_POST['solde'])?$_POST['solde']:"";
 $date_effet=isset($_POST['date_effet'])?$_POST['date_effet']:"";
 $date_reg=isset($_POST['date_reg'])?$_POST['date_reg']:"";
  $sql="UPDATE fractions SET montant='$montant',date_effet='$date_effet', date_reg='$date_reg',solde='$solde'  where id='$id' ";
$res=mysqli_query($conn,$sql);
echo '<script> window.location.href="reglerAffaire.php?id='.$idA.'"; </script>';

?>