<?php
 require_once("identifier.php");
  
require_once('connexiondb.php');
 $id=isset($_POST['id'])?$_POST['id']:0;
 $nomC=isset($_POST['nom'])?$_POST['nom']:"";
 $adresseC=isset($_POST['adresse'])?$_POST['adresse']:"";
 $cpC=isset($_POST['cp'])?$_POST['cp']:"";
 $villeC=isset($_POST['ville'])?$_POST['ville']:"";
 $telC=isset($_POST['tel'])?$_POST['tel']:"";
 $faxC=isset($_POST['fax'])?$_POST['fax']:"";
 $mailC=isset($_POST['mail'])?$_POST['mail']:"";
  $sql="UPDATE compagnies SET nom='$nomC',adresse='$adresseC' ,cp='$cpC', ville='$villeC' ,tel='$telC',fax='$faxC' ,mail='$mailC' where id='$id' ";
$res=mysqli_query($conn,$sql);
if($res){
	echo"les donnees sont modifiee.";?>
	
<script>
	window.location.href="compagnie.php";
</script>
	<?php
}
else {
	echo"erreur de modification";
}

?>