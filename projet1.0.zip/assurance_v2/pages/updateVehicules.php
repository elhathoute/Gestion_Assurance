
<?php
require_once("identifier.php");

require_once('connexiondb.php');                              

 $id=isset($_POST['id'])?$_POST['id']:0;
 $marque=isset($_POST['marque'])?$_POST['marque']:"";
 $matricule=isset($_POST['matricule'])?$_POST['matricule']:"";

 $requete="UPDATE risque SET marque='$marque', matricule='$matricule' where id='$id' ";


        $resultat=mysqli_query($conn,$requete);
     if($resultat){
     	echo '<script > window.location.href="vehicules.php"; </script>';
     }
       else 
       	echo "erreur";

 
?>