<?php 

require_once("identifier.php");
require_once "connexiondb.php";
 $cin=strtoupper(isset($_POST['cin'] ) ?$_POST['cin']:""); 
 $table=strtoupper(isset($_POST['table'] ) ?$_POST['table']:"");
 if(strlen($cin)>0){
 $req1="SELECT * from $table where UPPER($table.cin)='$cin' ";
 $res1=mysqli_query($conn,$req1);
	 echo
	 '<script>$(".CIN").css({
 	border:"none"
 	}); </script>';
 	echo'<script>$("#save01").removeAttr("disabled");</script>';
 if(mysqli_num_rows($res1)>0 and $cin!=''){
 	 echo'<span class="alert alert-danger">le cin d&eacute;ja existe!</span>';
    echo'<script> $(".CIN").css({
 	border:"5px solid red"
 	});
 	 </script>';
 	echo'<script>$("#save01").attr("disabled","");</script>';}

  }
	 
 ?>