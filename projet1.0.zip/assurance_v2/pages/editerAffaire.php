
<?php
require_once("identifier.php");
require_once "connexiondb.php";
 
  
?>
<!DOCTYPE HTML>
<html>
<head>

  <meta charset="utf-8">
  <title>Editer Affaire</title>
  <?php require("styleLinks.php");

  $id=isset($_GET['id'])?$_GET['id']:0;
  $requete="select * from affaires where id=$id";

  $resultat=mysqli_query($conn,$requete);
  $affaire=mysqli_fetch_array($resultat);
  $cmp=$affaire['compagnie'] ;
  $clt=$affaire['client'];
  $rsq=$affaire['risque'];
  $op=$affaire['op'];
  $req="SELECT compagnies.mail as'mail',compagnies.nom as'nomCmp', clients.cin as'cin', clients.nom as'nomClt', risque.matricule as'mat' from affaires,compagnies, clients, risque where (clients.id=affaires.client and  risque.id=affaires.risque and compagnies.id=affaires.compagnie) and (compagnies.id=$cmp and clients.id=$clt and risque.id=$rsq ) ";
  $res=mysqli_query($conn,$req);
  $aff=mysqli_fetch_assoc($res);

  ?>
  
</head>
<body>

 <?php 
 require_once("identifier.php");

 include("header.php");

   if($affaire['solde']==$affaire['production']){
  ?>


 <div class="container  col-lg-8 col-lg-offset-3 col-md-10 col-md-offset-1 col-sm-12 col-sm-offset-0">
     <?php
              if(isset($_POST['save'])){ ?>
     <div class="alert alert-danger">
                   
           ?>
          </div>
      <?php } ?>
   <div class="card margetop60"> 

    <div class="card-header bg-primary">Saisir les données d'Affaire</div>
    
    <div class="card-body text-info bg-light">
            
      <form method="post" action="updateAffaire.php" class="form">

        <div class="form-group form-inline ">
            id: &nbsp  <?php echo $affaire['id'] ?> &nbsp
          <input type="hidden" name="id"class="form-control" value="<?php echo $affaire['id'] ?>">
         Clients:
          <select  name="clt" class="form-control"  id="selectt">
            <option value="<?php echo $affaire['client'] ?>" class="default" selected ><?php echo $aff['nomClt'].' : '.$aff['cin'] ?></option>
           
             <?php  require_once "connexiondb.php";
             $req="select * from clients ";
             $res=mysqli_query($conn,$req);
             while($clients=mysqli_fetch_assoc($res)){?>
                <option value="<?php echo $clients['id']?>" ><?php echo $clients['nom']. ' : '.$clients['cin']?></option>
            <?php }?>
        </select>
         &nbsp &nbsp
        <label for=""> 
           CIN: 
           <input type="text" name="cin" placeholder="taper CIN"  id="cin"  class="form-control" ></label>
             &nbsp &nbsp 
           <select  name="cmp" class="form-control"  id="select2">
            <option value="<?php echo $affaire['compagnie'] ?>" class="default" selected ><?php echo  $aff['nomCmp'].' : '.$aff['mail'] ?></option>
             <?php  require_once "connexiondb.php";
             $req1="select * from compagnies ";
             $res1=mysqli_query($conn,$req1);
             while($compagnies=mysqli_fetch_assoc($res1)){?>
                <option value="<?php echo $compagnies['id']?>"><?php echo $compagnies['nom'].' : '.$compagnies['mail']?></option>
            <?php }?>
          </select>&nbsp &nbsp
           
          </div>
          <div id="hd">
           <table class="table table-responsive table-bordered" >
            <tr>
            <td>
         <div class="form-group ">
         <label >date d'assurer:
         <input type="date"
         name="datea" required 
         placeholder="date"
         class="form-control " value="<?php echo $affaire['datea'] ?>" /></label>
         </td>
         <td>
         <label >time:
         <input type="time"
         name="timea"  required value="<?php echo $affaire['timea']  ?>" 
         placeholder="time" 
         class="form-control"/></label>
         </td>
         <td>
         <label >police:
         <input type="text"
         name="police" required readonly
         placeholder="Taper un police" value="<?php  echo $affaire['police'] ?>"
         class="form-control" id="police"/></label>
         </td>
         </tr>

         <tr>
           <td>
            type:
            <select name="type"class="form-control" id="select3" >
                <option value="1" <?php if($affaire['type']==1) echo 'selected'; ?>>auto</option>
                <option value="0" <?php if($affaire['type']==0) echo 'selected'; ?>>moto</option>
            </select>
        </td>
        <td>
            ferme
            <select name="ferme"class="form-control" id="select4">
                <option value="0" <?php if($affaire['ferme']==0) echo 'selected'; ?> >ferme</option>
                <option value="1"<?php if($affaire['ferme']==1) echo 'selected'; ?> >ouvert</option>
            </select>
        </td>
        <td>
            matricule:
            <select name="risque"class="form-control" id="select5">
             <?php  require_once "connexiondb.php";
             $req2="select * from risque ";
             $res2=mysqli_query($conn,$req2);
             while($risque=mysqli_fetch_assoc($res2)){?>
                <option value="<?php echo $risque['id']?>" <?php if($affaire['risque']==$risque['id']) echo 'selected';  ?>><?php echo $risque['matricule']?></option>
            <?php }?>
        </select>
    </td>
</tr>

          <tr>
         <td>
        <label for="production">production:
        <input type="number" value="<?php echo $affaire['production'] ?>" step="any"min="0"
        name="production"  required id="prod"  
        class="form-control"/></label>
        </td>
        <td>
        <label for="fraction">nombre de fractions:
        <input type="number"min="1" max="12"
        name="nbrFractions"  value="<?php echo $affaire['nbrFractions'] ?>"
        placeholder="Taper un fraction" 
        class="form-control"/></label>
        </td>
        <td>
          
        <label for="op">operateur:&nbsp
        <input type="text" readonly
        name="op" value="<?php echo $_SESSION['email']?>" 
        class="form-control"/></label>
        </td>
         </tr>
          <tr>
         <td>
        dur&eacute;e:
         <select name="duree" class="form-control  date1" id="duree" required>
             <option value="1" <?php if($affaire['duree']==1) echo'selected'; ?>>1 mois</option>
             <option value="3" <?php if($affaire['duree']==3) echo'selected'; ?>>3 mois</option>
             <option value="6" <?php if($affaire['duree']==6) echo'selected'; ?>>6 mois</option>
             <option value="12" <?php if($affaire['duree']==12) echo'selected'; ?>>12 mois</option>
         </select>
         </td>
         <td>
        <label for="datei">date initiale:
        <input type="date"
        name="datei" id="datei" required
        min="<?php echo $affaire['datei']?>" value="<?php echo $affaire['datei'] ?>"
        class="form-control date1"/></label>
        </td>
         <td>
          
        <label for="datef">date finale:
        <input type="date"name="datef" id="datef"   value="<?php echo $affaire['datef']?>"
        class="form-control datef" readonly/></label>
        </td>
         </tr>
          <tr>
         <td>
        <label for="solde">solde en DH:
        <input type="number" value="<?php echo $affaire['solde'] ?>"step="any" min="0"
        name="solde" readonly  id="solde"  
        class="form-control"/></label>
        </td>
        <td>
        <label for="obs">observation:
        <input type="text"minlength="3"pattern="^([a-zA-Z]){3,}([\w\s])*"
        name="obs"  value="<?php echo $affaire['obs'] ?>" id="op"
        placeholder="Taper un obs" 
        class="form-control"/></label>
         </td>
         <td>
         &eacute;tat:
         <select name="etat" class="form-control col-lg-12 date1" id="etat">
             <option value="1" <?php if($affaire['etat']==1) echo'selected'; ?>>active</option>
             <option value="0"<?php if($affaire['etat']==0) echo'selected'; ?>>complet</option>
             <option value="-1" <?php  if($affaire['etat']==-1) echo'selected';?>>annuler</option>
         </select>
         </td>
          </tr>
          <tr>
         <td>
         <label >num&eacute;ro d'attestation: 
         <input type="text"
         name="numAttest" readonly
          value="<?php echo $affaire['numAttest']?>"
         class="form-control"/></label>
          </td>
         </tr>
          </table>
         
        <button type="reset" name="reset" class="btn btn-danger">
          <span class="fa fa-remove"></span> 
          Reset 
        </button>
         <button type="submit" name="save" class="btn btn-success" >
          <span class="fa fa-save"></span> 
          Save
        </button>&nbsp &nbsp
        <a href="javaScript:history.back()" id="rt">retour </a>
        </div>
      </div>

    </form>
  </div>
</div>
</div>
</div>
<?php }  
else 
echo '<script > window.location.href="affaires.php"; </script>';

?>
</body>


</html> 
 <?php
  include("footer.php");
  ?>