<?php  

        require_once("connexiondb.php");
        $input=isset($_POST['cin'] ) ?$_POST['cin']:"";
        $input=strtoupper($input);
       $requet =  "SELECT * FROM mandataires where UPPER(cin) like '$input%' or UPPER(tel
     ) like '$input%' or UPPER(mail) like'$input%' order by id desc";
        $requetCount="SELECT count(*) countM from mandataires where UPPER(cin) like'$input%' or UPPER(tel) like '$input%' or UPPER(mail) like'$input%'";
     
    
      $resultatManda = mysqli_query($conn,$requet) ;  
      $resultatCount =mysqli_query($conn,$requetCount) ;
      $tabCount= mysqli_fetch_array($resultatCount) ;
        $nbrMandataire= $tabCount['countM'];
       
       if(mysqli_num_rows($resultatManda)>0){
        echo '<table class="table table-striped tabble-border table-responsive tb"><tr><th><a href="clients.php" title="listes des clients">Id ['.$nbrMandataire.']</a></th> <th>Nom</th>  <th>CIN</th>  <th>Adress</th> <th>Ville</th><th>Cp</th>  <th>Tel</th>  <th>Ice</th> <th>Email</th><th>Activite</th><th>Obs</th>  <th>Action</th> 
        </tr>';
        while ($manda=mysqli_fetch_assoc($resultatManda)) {
          echo '<tr> <td>'. $manda["id"].' </td> <td> '.$manda["nom"].' </td><td>'. $manda["cin"].'</td> <td>' .$manda["adresse"].' </td><td>'. $manda["ville"] .'</td> <td>'. $manda["cp"].' </td> <td> '.$manda["tel"].'</td> <td>'. $manda["ice"].' </td> <td> '.$manda["mail"].' </td> <td> '.$manda["activite"].' </td><td>'. $manda["obs"].'</td> <td>
                            <a  href="editerMandataire.php?id='.$manda["id"].' " ><span class="fa fa-edit"></span></a> 
                              &nbsp
                         <a onclick="return confirm(\'vous etes sur de supp?\')"
                        href="supprimermandataire.php?id='.$manda["id"].' " ><span class="fa fa-trash"></span></a>
                           </td>';
        }
         echo "</tr></table>";
      

      } else echo '&nbsp &nbsp aucun mandataire trouv&eacute;.';
      


?>