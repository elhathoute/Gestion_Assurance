<?php
 require_once("identifier.php");


require_once('connexiondb.php');
 $id=isset($_GET['id'])?$_GET['id']:0;
 if($_SESSION['type']==1 && $_SESSION['id']!=$id){
  $sql="DELETE FROM users where id='$id' ";
$res=mysqli_query($conn,$sql);
if($res){
	echo"les donnees sont supprimee.";
	header("location:utilisateur.php");
}
else {
	echo"erreur de la supprission";
}
}
else 
  echo '<script > window.location.href="utilisateur.php"; </script>';
?>