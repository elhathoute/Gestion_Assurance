<?php

require_once("identifier.php");
require_once "connexiondb.php";
 
   $cin=isset($_POST['cin'] ) ?$_POST['cin']:"";
   $cin=strtoupper($cin);
   $req="SELECT * from clients where UPPER(cin) like '%$cin%' order by id desc";
 $res=mysqli_query($conn,$req);
    while($clients=mysqli_fetch_assoc($res)){
    echo '<option value="'.$clients['id'].' ">'.$clients['nom'].' : '.$clients['cin'].' </option>';
   }
?>