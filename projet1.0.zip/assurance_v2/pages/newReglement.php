<?php
require_once("identifier.php");
?>
<!DOCTYPE HTML>
<html>
<head>

  <meta charset="utf-8">
  <title>Nouvelle reglement</title>
  <?php require("styleLinks.php");?>


</head>
<body>

 <?php 
 require_once("identifier.php");

 include("header.php"); ?>


 <div class="container col-lg-4 col-lg-offset-3 col-md-8 col-md-offset-2">



   <div class="card  margetop60"> 

    <div class="card-header bg-primary">Saisir les données du reglement</div>
    
    <div class="card-body text-info bg-light">


      <form method="post" action="newReglement.php" class="form">
       <div class="form-group ">
         <label for="fraction">fraction:
         <input type="text"
         name="fraction" required
         placeholder="Taper une fraction" 
         class="form-control"/></label>

         <label for="montant">montant:
         <input type="number"
         name="montant"  required
         placeholder="Taper un montant" 
         class="form-control"/></label><br>

         <label >date:
         <input type="date"
         name="datea" disabled
         value="<?php echo date('Y-m-d') ?>" 
         class="form-control"/></label>&nbsp &nbsp &nbsp &nbsp

         <label for="mode">mode:
         <input type="text"
         name="mode"  required
         placeholder="Taper un mode" 
         class="form-control"/></label><br>

         <label for="ref">ref:
         <input type="text"
         name="ref"  required
         placeholder="Taper un ref" 
         class="form-control"/></label>

         <label for="validation">validation:
         <input type="number"
         name="validation" required
         placeholder="Taper un validation" 
         class="form-control"/></label>
         <br>
         <div class="err">
         	<?php if(isset($_POST['save']))
                 require 'insertReglement.php';
         	?>
         </div>
         <button type="reset" name="reset" class="btn btn-danger">
          <span class="fa fa-remove"></span> 
          Save
        </button>
        <button type="submit" name="save" class="btn btn-success" value="save">
          <span class="fa fa-save"></span> 
          Save
        </button>&nbsp &nbsp
       <a href="javaScript:history.back()" id="rt">retour </a>
      </div>
    </form>
  </div>
</div>

</div>


</body>

<footer>

  <?php
  include("footer.php");
  ?>
</footer>

</html> 