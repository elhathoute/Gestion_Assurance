

<?php
require 'identifier.php';
require_once("connexiondb.php");

$input=strtoupper(isset($_POST['nameC'])?$_POST['nameC']:"");

    $req="SELECT * from compagnies  order by id desc";
      $req="SELECT * from compagnies where UPPER(nom) like '$input%' or UPPER(mail) like '$input%' or UPPER(tel) like '$input%' order by id desc";
	$reqCount="SELECT count(*) countU from compagnies where UPPER(nom) like '$input%' or UPPER(mail) like '$input%' or UPPER(tel) like '$input%'  ";
$res=mysqli_query($conn,$req);
if(mysqli_num_rows($res)>0){
$reqCount=mysqli_query($conn,$reqCount);
$tabCount=mysqli_fetch_assoc($reqCount);
$nbrCompagnies=$tabCount['countU'];

echo '<table class="table table-striped tabble-border table-responsive tb"><tr> <th>Id ['.$nbrCompagnies.']</th>
	  <th>nom</th>
	 <th>adresse</th>
	 <th>cp</th>
	  <th>ville</th>
	 <th>tel</th>
	 <th>fax</th>
	 <th>mail</th>
	 <th>actions</th>';
	 
while ($compagnies=mysqli_fetch_assoc($res)) {

	echo '<tr> <td>'. $compagnies["id"].' </td> <td> '.$compagnies["nom"].' </td><td>'. $compagnies["adresse"] .'</td><td>'. $compagnies["cp"].' </td> <td> '.$compagnies["ville"].' </td><td>'. $compagnies["tel"] .'</td> <td> ' .$compagnies["fax"].' </td><td>'. $compagnies["mail"] .'</td> <td>
		<a  href="editCompagnie.php?id='.$compagnies["id"].' " ><span class="fa fa-edit"></span></a> 
		&nbsp
		<a onclick="return confirm(\'vous etes sur de supp?\')"
		href="deleteCompagnie.php?id='.$compagnies["id"].' " ><span class="fa fa-trash"></span></a></td> ';
	    				
        }
         echo "</tr></table>";
   }

   else echo '&nbsp &nbsp &nbsp aucune compagnie trouv&eacute;e';
        ?>