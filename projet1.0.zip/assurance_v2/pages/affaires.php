
<?php
require_once("identifier.php");

require_once("connexiondb.php");

$size=isset($_GET['size'] ) ?$_GET['size']: 20;    
$page=isset($_GET['page'] ) ?$_GET['page']: 1;
$input=strtoupper(isset($_GET['client'])?$_GET['client']:"");
$offset= ($page-1)*$size ; 
$requet =  "SELECT affaires.id as'id',affaires.datea,affaires.timea,compagnies.mail as'mail1',affaires.police,affaires.numAttest,affaires.type,affaires.ferme,clients.cin,risque.matricule , affaires.production,affaires.nbrFractions,affaires.duree,affaires.datei,affaires.datef,affaires.solde,affaires.obs,affaires.etat,affaires.op FROM affaires , clients, risque,compagnies where (clients.id=affaires.client and  risque.id=affaires.risque and compagnies.id=affaires.compagnie) and (UPPER(cin) like'$input%' or UPPER(police) like'$input%' or UPPER(matricule) like'$input%')
order by affaires.id desc limit $size 
offset $offset ";
$requetCount="SELECT count(*) countC FROM affaires , clients, risque where (clients.id=affaires.client and risque.id=affaires.risque ) and  (UPPER(clients.cin) like'$input%' or  UPPER(police) like'$input%' or UPPER(risque.matricule) like'$input%')";

$resultatAffaire = mysqli_query( $conn,$requet) ;  
$resultatCount =mysqli_query( $conn,$requetCount) ;
$tabCount=  mysqli_fetch_array($resultatCount) ;
$nbrAffaire= $tabCount['countC'];
$rest=$nbrAffaire%$size;  
if($rest===0)
  $nbrPage=$nbrAffaire / $size;
else
  $nbrPage= floor($nbrAffaire/ $size) +1; 
?>
<!DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
  <title>Gestion des affaires</title>
  <?php require("styleLinks.php");?>
</head>
<body>
 <?php
 include("header.php");
 ?>
 <div class="container col-lg-12 col-md-12 col-sm-12">
  <!-- panneau de recherche-->  
  <div class="card  margetop60"> 
   <!-- intégrer la partie de recherche !-->

   <div class="card-header bg-success">

     Rechercher et Ajouter des affaires
   </div>
   <!--intégrer le contenu de recherche !-->
   <div class="card-body">
    <form method="get" action="affaires.php" class="form-inline">
     <div class="form-group">

      <input type="text" 
      name="client" autocomplete="off"
      placeholder="rechercher par cin du client, matricule ou police" 
      class="form-control inp" id="aff1"
      value="<?php echo $input ?>">
    </div>
    &nbsp &nbsp &nbsp &nbsp
    <a method="post" href="nouvelleAffaire.php "> Ajouter Affaire
     <span class="fa fa-plus"></span>
   </a>
 </form>
</div>
</div>
<!--------------------------------------------------------- -->

<!-- panneau du contenu de l'interface-->

<div class="card  "> 

  <div class="card-header bg-primary">Liste des Affaires  [<?php echo $nbrAffaire ?>  Affaires] </div>

  <div  class="card-body text-info bg-light">
   <div id="aff2">
    <table  class="table table-striped table-bordered  table-responsive tb">
      <thead >
       <tr >
        <th>Id[<?php echo $nbrAffaire ?>]</th> <th>Date_d'assurer</th>  <th>Time</th>  <th>Compagnie</th>  <th>Police</th> <th>N_Attestation</th>    
        <th>Type</th>  <th>Ferme</th> <th>Client</th> <th>Risque_matr</th> <th>Production</th><th><a href="fractions.php?>" title="les fractions">nFractions</a></th>
        <th>Duree</th>  <th>Date_debut</th> <th>Date_fin_aff</th> <th>Solde</th><th>Etat</th><th>Op&eacute;rateur</th><th>Observation</th><th>Actions</th>

      </tr>
    </thead>
    <tbody>
      <?php while($affaire = mysqli_fetch_array($resultatAffaire)) { 
         $affr=$affaire['id'];
                      $req="SELECT * from fractions where affaire=$affr";
                       $res=mysqli_query($conn,$req);
                     $bgClr=mysqli_num_rows($res)>0?'bg-white':'';
                     $clr=mysqli_num_rows($res)>0?'text-dark':'';
                      $bgClr=$affaire['solde']!=$affaire['production']?'bg-warning':$bgClr;?>
        <!--code Html pour remplier le tab-->
        <tr class="<?php echo $bgClr.' '.$clr;  ?> ">
          <td> <?php echo $affaire['id'] ?> </td>
          <td> <?php echo $affaire['datea'] ?> </td>
          <td> <?php echo $affaire['timea'] ?> </td>
          <td><a href="compagnie.php?nameC=<?php echo $affaire['mail1'] ?>"> <?php echo $affaire['mail1'] ?> </td>
          <td> <?php echo $affaire['police'] ?> </td>
          <td> <?php echo $affaire['numAttest'] ?> </td>
          <td> <?php 
          $type=$affaire['type']==1? 'auto':'moto';
          echo  $type ?> </td>
          <td> <?php
          $ferme=$affaire['ferme']==1? 'ouvert':'ferme';
          echo  $ferme ?> </td>
          <td> <a href="clients.php?cin=<?php echo $affaire['cin'] ?>"><?php echo $affaire['cin'] ?></a> </td>
          <td><a href="vehicules.php?matricule=<?php echo $affaire['matricule'] ?>" > <?php echo $affaire['matricule'] ?> </a></td>
          <td> <?php echo $affaire['production'] ?> </td>
          <td><a href="fractions.php?fraction=<?php echo $affaire['police'] ?>"> <?php echo $affaire['nbrFractions'] ?> fractions</a> </td>
          <td> <?php echo $affaire['duree'] ?> mois</td>
          <td> <?php echo $affaire['datei'] ?> </td>
          <td> <?php echo $affaire['datef'] ?> </td>
          <td> <?php echo $affaire['solde'] ?> DH</td>
          
          <td> <?php 
          $et=$affaire['etat'];
          if($et==1)
            $etat="active";
          else if($et==0)
            $etat="complet";
          else $etat="annuler";

          echo $etat ?> </td>
          <td> <a href="utilisateur.php?loginU=<?php echo $affaire['op'] ?>" ><?php echo $affaire['op'] ?> </a></td>
          <td> <?php echo $affaire['obs'] ?> </td>
          <td>
            
            <?php if($affaire['solde']==$affaire['production'] ){ ?>
            <a  href="editerAffaire.php?id=<?php echo $affaire['id'] ?>" > <span class="fa fa-edit"></span></a> 
            &nbsp
           <a onclick="return confirm('vous etes sur!')" href="supprimerAffaire?id=<?php echo $affaire['id'] ?>" ><span class="fa fa-trash"></span></a>
         
        <?php } ?>
         </td>
        </tr>
      <?php  } ?>

    </tbody>
  </table>
  </div>
  <div >
   <ul class="pagination ">
    <?php
    for($i=1;$i<=$nbrPage;$i++){ ?>

     <li class="<?php if($i == $page) echo'active' ?> page-item"> <a class="page-link"href="affaires.php ?page=<?php echo $i;?>">  <?php echo $i;?>  </a> </li> 

   <?php   } ?>

 </ul>
</div>
<a href="javaScript:history.back()" id="rt">retour </a>
</div>
</div>
</div>

</body>



</html><?php
include("footer.php");
?>