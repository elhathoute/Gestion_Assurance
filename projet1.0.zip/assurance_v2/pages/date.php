<?php

require_once("identifier.php");
require_once "connexiondb.php";
$duree=isset($_POST['duree'] ) ?$_POST['duree']:"";
$datei=isset($_POST['datei'] ) ?$_POST['datei']:"";
$duree=($duree*30).' days';
echo date('Y-m-d', strtotime($datei.' +'.$duree));

?>