<?php 

require_once("identifier.php");
require_once "connexiondb.php";
 $email=strtoupper(isset($_POST['email'] ) ?$_POST['email']:""); 
 $table=strtoupper(isset($_POST['table'] ) ?$_POST['table']:"");
 if(strlen($email)>0){
 $req1="SELECT * from $table where UPPER($table.mail)='$email' ";
 $res1=mysqli_query($conn,$req1);
    echo
    '<script>$(".email").css({
   boxShadow: "2px 2px 5px 2px green"
   }); </script>';
   echo'<script>$("#save02").removeAttr("disabled");</script>';
 if(mysqli_num_rows($res1)>0 and $email!=''){
    echo"<span class='alert alert-danger'>l'email d&eacute;ja existe!</span>";
    echo'<script> $(".email").css({
   boxShadow: "2px 2px 5px 2px red"
   });
    </script>';
   echo'<script>$("#save02").attr("disabled","");</script>';}

  }
    
 ?>