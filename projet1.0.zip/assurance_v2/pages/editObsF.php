<?php
 require_once("identifier.php");
 
 require_once ("connexiondb.php");
 $id=isset($_GET['id'])?$_GET['id']:0;
 $req="select * from fractions where id='$id'";
 $res=mysqli_query($conn,$req);
 $fraction=mysqli_fetch_assoc($res);
 $obs=$fraction['obs'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>edit observation fraction</title>
<?php require("styleLinks.php");?>
</head>
<body>
	<?php
     include("header.php");
	?>
<div class="container col-lg-5 col-lg-offset-3 col-md-6 col-md-offset-3">
	<div class="util" >
	<div class="card">
		<div class="card-header bg-info text-white">
		modifier observation</div>
	    <div class="card-body text-info bg-light">
	    	<form method="get" action="updateObsF.php" class="form-check" >

 			<div class="form-group">
        <label>id : <?php echo $id ?></label>
        <input type="hidden" name="id" value="<?php echo $id ?>" ><br>
         <label>Observation:</label><br>
        <textarea class="form-control" name="obs" id="editObsF" <?php if(!$obs) echo 'autofocus'?>><?php echo $obs?></textarea>

 				<br><br>

         &nbsp &nbsp<button type="reset" name="reset"class="btn btn-danger" >
            <i class="fa fa-remove"></i> &nbsp reset
          </button>&nbsp &nbsp
 					<button type="submit" name="subO"class="btn btn-success" >
 						<i class="fa fa-save"></i> &nbsp modifier
 					</button>
         
 					<a href="javaScript:history.back()" id="rt">retour </a>
 			</div>



	    </div>
</div>

</div></div>
<?php include'footer.php'; 


?>
</body>
</html>




