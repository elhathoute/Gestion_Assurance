<?php
 require_once("identifier.php");
 require_once ("connexiondb.php");
 $id=isset($_GET['id'])?$_GET['id']:0;
 $req="select * from users where id='$id'";
 $res=mysqli_query($conn,$req);
 $user1=mysqli_fetch_assoc($res);
 $login=$user1['login'];
 $pwd=$user1['pwd'];
 $email=$user1['email'];
 $type=$user1['type'];
 $etat=$user1['etat'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>utilisateur</title>
	<?php require("styleLinks.php");?>
</head>
<body>
	<?php
     include("header.php");
     if($_SESSION['type']==1 &&  $_SESSION['id']!=$id){
	?>
<div class="container col-lg-4 col-lg-offset-3 col-md-6 col-md-offset-3 ">
	<div class="util" >
	<div class="card">
		<div class="card-header bg-info text-white">
		modifier un utilisateur</div>
	    <div class="card-body text-info bg-light">
	    	<form method="post" action="editUser.php" class="form-check">
 			<div class="form-group ">
 					<input type="hidden" name="id" class="form-control" autocomplete="off" value="<?php echo $id?>"></label><br>
 					<label>login:</label>
          <input type="text" name="login"value="<?php echo $login?>" class="form-control" minlength="3" maxlength="30" pattern="^[a-zA-Z\s_]{3,}$" autocomplete="off"required><br>
          <label >password:</label>
         <input type="password" id="pass1"name="pwd" value="<?php echo $pwd?>"minlength="4" maxlength="20"class="form-control"required><span id="iconn2" class="ico"> <i  class="fa fa-eye-slash fa-3x"></i></span>
         <br>
         <label>email:</label>
          <input type="email" name="email"class="form-control" value="<?php echo $email?>"  minlength="11" maxlength="50" pattern="^([a-zA-Z]){1}([\w.])*(@gmail\.com){1}$" autocomplete="off"required>
          <br>
          <input type="hidden" name="type"class="form-control" autocomplete="off" value="<?php echo $type?>" required><br>
          <input type="hidden" name="etat"class="form-control" autocomplete="off" value="<?php echo $etat?>" required>
                <div class="err">
                	<?php 
                	if(isset($_POST['sub4']))
                     require("updateUser.php");
                	?>
                </div>	
 					<button type="submit" name="sub4"class="btn btn-success" >
 						<i class="fa fa-save"></i> &nbsp modifier
 					</button>
          &nbsp &nbsp
 					<a href="javaScript:history.back()" id="rt">retour </a>
 			</div>



	    </div>
</div>

</div></div>
<?php
include 'footer.php';
}
else 
  echo '<script > window.location.href="utilisateur.php"; </script>';
?>
</body>
</html>