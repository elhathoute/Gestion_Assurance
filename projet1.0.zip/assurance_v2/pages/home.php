<?php
require_once("identifier.php");
?>
<!DOCTYPE html>
<html>
<head>
  <title>AR Assurance</title>
  <?php require("styleLinks.php");?>

</head>
<body >
	<header id="header" >
		<?php 
          
		include("header.php");
		?>
	</header>
    <main>
         <div class="main">
          <div class="acc">
			<p id="c1">ASSURANCE</p>
			<P id="c2">
				BIENVENUE CHEZ NOUS <br>
				
			</P>
 </div></div>
    </main>   
<footer>
		<?php 
		include("footer.php");
		?>
	</footer>
</body>
</html>
