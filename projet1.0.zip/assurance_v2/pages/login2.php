  <?php
  session_start();
  if(isset($_SESSION['erreur']))
  	$err=$_SESSION['erreur'];
  else 
  	$err="";
  if(!isset($_SESSION['check']))
  	session_destroy();

  ?>
  <!DOCTYPE html>
  <html>
  <head>
  	<title>AR Assurance</title>
  	<link rel="stylesheet" type="text/css" href="../styles/bootstrap/css/bootstrap.min.css">
  	<link rel="stylesheet" type="text/css" href="../styles/font-awesome/css/font-awesome.min.css">
  	<link rel="stylesheet" type="text/css" href="../styles/css/style2.css">
  	<link rel='shortcut icon' href='../images/AssuranceAR1.png' />
  	<script src="../styles/bootstrap/js/bootstrap.bundle.min.js" ></script>
  	<script src="../js/jquery.js"></script>
  	<script src="../js/js3.js"></script>
  </head>
  <body>
  	<div class="container col-lg-6 col-md-10 col-md-offset-2 col-sm-11">
  		
  		<br/>
  		<center> <b id="login-name">Se connecter</b> </center>
  		<div  id="login">  

  			<form  method="post" action="log2.php"id="sub3">

  				<div class="form-group">
  					<label class="user"> NOM D'UTILISATEUR</label>
  					<div class="input-group">
  						<span class="input-group-addon" id="iconn"> <i class="fa fa-user fa-3x"></i></span>
  						<input type="text" class="form-control ipt" id="user1" name="login"  autocomplete="off" placeholder="nom d'utilisateur" value="<?php if(isset($_SESSION['check']))
  						echo $_SESSION['user'];?>" required>
  					</div>

  					<div class="erru"></div>
  				</div>

  				<div class="form-group">
  					<label class="user"> MOT DE PASSE</label>
  					<div class="input-group">

  						<span  id="iconn1"> <i class="fa fa-lock fa-3x"></i></span>
  						<input type="password" class="form-control ipt" id="pass1"placeholder="mot de passe" name="pwd"  required value="<?php if (isset($_SESSION['check']))
  						echo $_SESSION['pwd']; ?>">
  						<span id="iconn2"> <i  class="fa fa-eye-slash fa-3x"></i></span>
  					</div>
  					<br>
  					<div class="form-group">
  							<input type="checkbox" <?php if (isset($_SESSION['check']))
  							echo 'checked' ?> value="oui" name="check" id="check" /><span class="caption">&nbsp Remember me</span>
  						</div>

  						<div class="errp"> 
  							<?php if(!empty($err)) {?>
  								<div class="alert alert-danger "id="errLog"role="alert">
  									<i class="fa fa-exclamation-triangle"></i>&nbsp &nbsp<?php echo $err ?>
  								</div>
  							<?php }  
  							?>
  						</div>
  						<br>
  						<button type="submit" name="submit"class="btn btn-outline-success ipt"id="log" id="sub5"><i class="fa fa-sign-in"></i>&nbsp 
  							Se connecter
  						</button>
  						<br/><br/><br/>
                        <center>
  						<a id="fp" href="forgetPassword.php" >Mot de passe oubli&eacute;?</a></center>
  					</form>
  				</div>
  			</div>
  		</body>
  		</html>