<?php
require_once("identifier.php");

require_once("connexiondb.php");


$dureeR=isset($_GET['dureeR'])?$_GET['dureeR']:30;

$dateA=date('Y-m-d',strtotime('-1 day'));
if ($dureeR==1)
  $dateR=strtotime($dateA.' -'.$dureeR.' day');
else
$dateR=strtotime($dateA.' -'.$dureeR.' days');

$dateA=strtotime(date('Y-m-d',strtotime('-1 day')));
$requet =  "SELECT affaires.id,affaires.datea,affaires.timea,compagnies.mail as'mail1',affaires.police,affaires.numAttest,affaires.type,affaires.ferme,clients.cin as'cin1',risque.matricule as'mat1', affaires.production,affaires.nbrFractions,affaires.duree,affaires.datei,affaires.datef,affaires.solde,affaires.obs,affaires.etat,affaires.op FROM affaires , clients, risque,compagnies where (clients.id=affaires.client and  risque.id=affaires.risque and compagnies.id=affaires.compagnie) and (UNIX_TIMESTAMP(affaires.datef) < $dateA and UNIX_TIMESTAMP(affaires.datef)>= $dateR)
order by affaires.datef desc ";
$requetCount="SELECT count(*) countC FROM affaires , clients, risque where (clients.id=affaires.client and risque.id=affaires.risque ) and (UNIX_TIMESTAMP(affaires.datef) < $dateA and UNIX_TIMESTAMP(affaires.datef) >=  $dateR) ";

$resultatAffaire = mysqli_query( $conn,$requet) ;  
$resultatCount =mysqli_query( $conn,$requetCount) ;
$tabCount=  mysqli_fetch_array($resultatCount) ;
$nbrAffaire= $tabCount['countC'];
if(mysqli_num_rows( $resultatAffaire)){
       echo '<table class="table table-striped table-bordered table-responsive tb"><tr><th>Id ['.$nbrAffaire.']</th> <th>Date_d\'assurer</th>  <th>Time</th>  <th>Compagnie</th>  <th>Police</th> <th>N_Attestation</th>    
        <th>Type</th>  <th>Ferme</th> <th>Client</th> <th>Risque_matr</th> <th>Production</th><th><a href="fractions.php?>" title="les fractions">nFractions</a></th>
        <th>Duree</th>  <th>Date_debut</th> <th>Date_fin_aff</th> <th>Solde</th><th>Etat</th><th>Op&eacute;rateur</th><th>Observation</th>
                   </tr>';
        while ($affaire=mysqli_fetch_assoc($resultatAffaire)) {
          $affr=$affaire['id'];
                      $req="SELECT * from fractions where affaire=$affr";
                       $res=mysqli_query($conn,$req);
                     $bgClr=mysqli_num_rows($res)>0?'bg-white':'';
                     $clr=mysqli_num_rows($res)>0?'text-dark':'';
                     $bgClr=$affaire['solde']!=$affaire['production']?'bg-warning':$bgClr;
          $type=$affaire['type']==1? 'auto':'moto';
 $ferme=$affaire['ferme']==1? 'ouvert':'ferme';
 $et=$affaire['etat'];
          if($et==1)
            $etat="active";
          else if($et==0)
            $etat="complet";
          else $etat="annuler";
          
          echo '<tr class="'.$clr.' '.$bgClr.'"> <td>'. $affaire["id"].' </td> <td> '.$affaire["datea"].' </td><td>'. $affaire["timea"] .'</td> <td><a href="compagnie.php?nameC='. $affaire["mail1"].'">'. $affaire["mail1"].' </a></td> <td><a href="affaires.php?client='. $affaire["police"].'">'.$affaire["police"].' </td><td>'. $affaire["numAttest"] .'</td> <td>'. $type.' </td> <td> '.$ferme.' </td><td> <a href="clients.php?cin='. $affaire["cin1"] .'">'. $affaire["cin1"] .'</a></td> <td><a href="vehicules.php?matricule='. $affaire["mat1"].'">'. $affaire["mat1"].'</a></td> <td> '.$affaire["production"].' </td> <td><a href="fractions.php?fraction='.$affaire["police"].'">'.$affaire["nbrFractions"].' fractions</a></td><td>'. $affaire["duree"].' mois' .'</td> <td>'. $affaire["datei"].' </td> <td> '.$affaire["datef"].' </td><td> '.$affaire["solde"].' DH'.' </td><td> '.$etat.' </td><td><a href="utilisateur.php?loginU='.$affaire["op"].'">'.$affaire["op"].'</a> </td><td> <textarea name="obs" id="obs1" readonly class="'.$bgClr.'">'.$affaire["obs"].'</textarea> <br>
            &nbsp <a href="editObsA.php?id='.$affaire["id"] .'" > <i class="fa fa-edit"></i> </a>&nbsp &nbsp &nbsp &nbsp
         <a href="supprimerObsA.php?id='.$affaire["id"] .'" > <i class="fa fa-trash"></i> </a>
           
          </td>';
        }
         echo "</tr></table>";
      
      
      }
      else echo '&nbsp &nbsp &nbsp aucune affaire trouv&eacutee;.';

?>