<?php
    require_once("identifier.php");

        require_once("connexiondb.php");

        
       $size=isset($_GET['size'] ) ?$_GET['size']: 20;     //nbr limite qui affiche dans la page
        $page=isset($_GET['page'] ) ?$_GET['page']: 1;
        $offset= ($page-1)*$size ;  //nbr de sauter
//récuperer une parametre envoyer par la methode GET
      $fraction=strtoupper(isset($_POST['fraction'])?$_POST['fraction']:"");

      $requet ="SELECT fractions.id,fractions.affaire as'affaire',clients.cin as'cin',risque.matricule as'matricule',affaires.police as'police',affaires.id as'idF',fractions.montant,fractions.date_effet,fractions.date_reg,fractions.solde as'solde' FROM fractions,clients,risque,affaires where (affaires.client=clients.id and affaires.risque=risque.id and affaires.id=fractions.affaire)
        and (UPPER(affaires.police) like'$fraction%'  or UPPER(clients.cin) like'$fraction%'or UPPER(risque.matricule) like'$fraction%') order by fractions.id desc";
      $requetCount="SELECT count(*) countF from fractions,clients,risque,affaires where (affaires.client=clients.id and affaires.risque=risque.id and affaires.id=fractions.affaire) and (UPPER(affaires.police) like'$fraction%' or UPPER(clients.cin) like'$fraction%'or UPPER(risque.matricule) like'$fraction%')";
      //la fct query() pour execut la requet SELECT
     
    
        $resultatFraction = mysqli_query($conn,$requet) ;  
        $resultatCount = mysqli_query($conn,$requetCount) ;
        if( $resultatCount)
        $tabCount =  mysqli_fetch_assoc($resultatCount) ;
        $nbrFraction = $tabCount['countF'];

    if(mysqli_num_rows($resultatFraction)>0 ){
       echo '<table class="table table-striped table-bordered table-responsive tb"><tr><th>Id ['.$nbrFraction.']</th> <th>police</th>  <th>client</th>  <th>risque</th>  <th>montant</th> <th>date_effet</th>    
                    <th>solde</th><th>date_regl</th>       
                   </tr>';
        while ($fraction=mysqli_fetch_assoc($resultatFraction)) {
           $idF=$fraction['idF'];
                      $req="SELECT * from reglement,fractions where (fractions.id=reglement.fraction) and fractions.affaire=$idF";
                        $res=mysqli_query($conn,$req);
                       $bgClr=mysqli_num_rows($res)>0?'bg-warning':'';
                       $clr=mysqli_num_rows($res)>0?'text-white':'';
          echo '<tr class="'.$clr.' '.$bgClr.'"> <td>'. $fraction["id"].' </td> <td> '.$fraction["police"].' </td><td>'. $fraction["cin"] .'</td> <td>'. $fraction["matricule"].' </td> <td> '.$fraction["montant"].' </td><td>'.$fraction["date_effet"] .'</td> <td>'.$fraction["solde"].' DH</td> <td>'.$fraction["date_reg"].'</td>';
  
        }
        echo "</tr></table>";
      
      }
      else echo '&nbsp &nbsp &nbsp aucune fraction trouv&eacute;.'; 

?>






        