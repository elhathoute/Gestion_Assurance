
<div class="hd"></div>
<div class="toggle">
 <div class="head tg">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" id="accueil"href="home.php">
    
    <i class="fa fa-home"></i>
    Accueil</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="clients.php" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="fa fa-user"></i> 
            Client
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" id="client" href="clients.php">
           <i class="fa fa-male"></i>
            Client</a></li>
            <li><a class="dropdown-item" id="mandataire"href="mandataires.php">
            <i class="fa fa-male"></i>
            Mandataire</a></li>
            
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="vehicule"href="vehicules.php">
             <i class="fa fa-automobile"></i>
            Vehicule
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link"id="affaires" href="affaires.php">
          <i class=" fa "></i>
          Affaires</a>
        </li>

        <li class="nav-item">
          <a class="nav-link"id="reglement" href="reglement.php">
          <i class=" fa fa-cc-visa"></i>
          Reglement</a>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fa"></i> &nbsp Relance
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" id="renouvellement" href="renouvellement.php">
            <i class=" fa "></i>
            renouvellement</a></li>
            <li><a class="dropdown-item" id="paiement"href="paiement.php">
            <i class="fa"></i>
          
            paiement</a></li>
            </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fa fa-cog"></i> &nbsp Paramettre
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" id="compagnie" href="compagnie.php">
            <i class=" fa  fa-university "></i>
            Compagnie</a></li>
            <?php if($_SESSION['type']==1){?>
            <li><a class="dropdown-item" id="utilisateur"href="utilisateur.php">
            <i class="fa  fa-user-circle-o"></i>
            Utilisateur</a></li>
          <?php } ?>
          </ul>
        </li>
        </ul>
        <ul class="navbar-nav"> 
        <li class="nav-item profil">
           
          <a class="nav-link" id="user4"href="editUser2.php"> <i class="fa fa-user"> </i>&nbsp &nbsp
            <?php 
                
                 if(isset($_SESSION['user']) && isset($_SESSION['type'])){
                if($_SESSION['type']==1)
                  $type1='admin';
                else 
                  $type1="user";
                echo $_SESSION['user'].' : '.$type1;
              }
             ?>
          
        </a>
        </li>
         <li class="nav-item dec">
          <a class="nav-link" id="etat"href="login2.php"><i class="fa fa-sign-out "></i>&nbsp Se d&eacute;connecter</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
</div>
 </div>