
<?php
require_once 'identifier.php';
require_once('connexiondb.php');

 $size=isset($_GET['size'] ) ?$_GET['size']:10;     //nbr limite qui affiche dans la page
        $page=isset($_GET['page'] ) ?$_GET['page']: 1;
        $offset= ($page-1)*$size ;
$nameC=strtoupper(isset($_GET['nameC'])?$_GET['nameC']:"");
$req="SELECT * from compagnies where UPPER(mail) like '$nameC%' order by id desc limit $size  offset $offset";
 $reqCount="SELECT count(*) countC from compagnies  where UPPER(mail) like '$nameC%'";

$res=mysqli_query($conn,$req);
$reqCount=mysqli_query($conn,$reqCount);
$tabCount=mysqli_fetch_assoc($reqCount);
$nbrComp=$tabCount['countC'];
       $rest= $nbrComp%$size;
       if($rest===0)
          $nbrPage=$nbrComp / $size;
          else
          $nbrPage= floor($nbrComp / $size) +1; //la partie reel plus 1

?>

<!DOCTYPE html>
<html>
<head>
	<title>compagnies</title>
	<?php require("styleLinks.php");?>
</head>
<body>
	<?php
     include("header.php");
	?>
<div class="container col-lg-6 col-md-12 col-sm-12">
	<div class="util mw" >
	<div class="card">
		<div class="card-header bg-success text-white">Rechercher des compagnies...</div>
	    <div class="card-body">
	    	 <form method="post" action="compagnie.php" class="form-inline">
	    	 	
	    	 	<div class="form-group">
	    	 		
	    	 	<input type="text" class="form-control" name="nameC" id="nameC" placeholder="nom, email ou tel" 
	    	 	 value="<?php echo $nameC ?>" autocomplete="off" >
	    	 	<a href="newCompagnie.php">&nbsp &nbsp Ajouter une Compagnie <i class="fa fa-plus"></i></a>
	    	 	
	    	 	</div>
	    	 
	    	 </form>
	    </div>
	</div>

	<div class="card ">
		<div class="card-header bg-primary text-white">
		List des compagnies (<?php echo $nbrComp ?> compagnies)</div>
	    <div  class="card-body">
	    	<div id="resC">
	    	<table class="table table-striped table-bordered table-responsive">
	    		<thead>
	    			<tr>
	    				<th>id [<?php echo $nbrComp ?> ]</th>
	    				<th>nom</th>
	    				<th>adresse</th>
	    				<th>cp</th>
	    				<th>ville</th>
	    				<th>tel</th>
	    				<th>fax</th>
	    				<th>mail</th>
	    				<th>actions</th>
	    			</tr>
	    		</thead>
	    		<tbody>
	    			<?php
	    			while($comp=mysqli_fetch_assoc($res)){
	    				?>
	    			<tr>
	    				<td><?php echo $comp["id"] ?></td>
	    				<td><?php echo $comp["nom"] ?></td>
	    				<td><?php echo $comp["adresse"] ?></td>
	    				<td><?php echo $comp["cp"] ?></td>
	    				<td><?php echo $comp["ville"] ?></td>
	    				<td><?php echo $comp["tel"] ?></td>
	    				<td><?php echo $comp["fax"] ?></td>
	    				<td><?php echo $comp["mail"] ?></td>
	    				
	    				<td>
	    					<a  href="editCompagnie.php?id=<?php echo $comp['id']?>"title="edit compagnie">
	    						<i class="fa fa-edit"></i>
	    					</a>&nbsp &nbsp
	    				 <a onclick="return confirm('etes sur de vouloir supprimer la compagnie ')" href="deleteCompagnie.php?id=<?php echo $comp['id']?>" title="delete compagnie">
	    				<i class="fa fa-trash"></i>
	    				</a></td>
	    			
	    			</tr>
	    			<?php }?>
	    		</tbody>
	    	</table>
	    	</div>
            <div >
                       <ul class="pagination ">
                        <?php
                        for($i=1;$i<=$nbrPage;$i++){ ?>
                          
                         <li class="<?php if($i == $page) echo'active' ?> page-item"> <a  class="page-link"href="compagnie.php?page=<?php echo $i;?>">  <?php echo $i;?>  </a> </li> 

                       <?php   } ?>
                              
                        </ul>
                    </div>
              <a href="javaScript:history.back()" id="rt">retour </a>
	    </div>
	</div>
	</div>
</div>
<?php
include 'footer.php';
?>
</body>
</html>
