<?php
 require_once("identifier.php");
 
 require_once ("connexiondb.php");
 $id=isset($_GET['id'])?$_GET['id']:0;
 $sql="SELECT * from compagnies where id='$id' ";
 $res=mysqli_query($conn,$sql);
 $rows=mysqli_fetch_assoc($res);
 $nom=$rows['nom'];
 $adresse=$rows['adresse'];
 $cp=$rows['cp'];
 $ville=$rows['ville'];
 $tel=$rows['tel'];
 $fax=$rows['fax'];
 $mail=$rows['mail'];

?>
<!DOCTYPE html>
<html>
<head>
	<title>edit Compagnie</title>
	<?php require("styleLinks.php");?>
</head>
<body>
	<?php
     include("header.php");
	?>
<div class="container col-lg-4 col-lg-offset-3">
	<div class="util" >
	<div class="card">
		<div class="card-header bg-info text-white">
		modifier un utilisateur</div>
	    <div class="card-body text-info bg-light">
	    	<form method="post" action="editCompagnie.php" class="form" >

 			<div class="form-group">
 				<label>id: <?php echo $id?>
 					<input type="hidden" name="id" class="form-control" autocomplete="off"  value="<?php echo $id ?>"></label><br>
 					<div class="form-group" >
 				<label>nom:
 					<input type="text" name="nom" class="form-control"minlength="3" maxlength="30" pattern="^[a-zA-Z\s_]{3,}$"  autocomplete="off" required value="<?php echo $nom ?>"></label>
 					<label >adresse:
 			   <input type="text" name="adresse"class="form-control"minlength="3" maxlength="500" pattern="([\w\s-]){3,}" autocomplete="off" value="<?php echo $adresse ?>"></input>
 			   </label>
 			   <label>cp:
 					<input type="text" name="cp"class="form-control" minlength="3" maxlength="20"pattern="^([\d]){3,}"autocomplete="off" value="<?php echo $cp ?>"></label> 
 					<label>ville:
 					<input type="text" name="ville" class="form-control" minlength="3" maxlength="50"pattern="^([a-zA-Z_ \s -]){3,}$"autocomplete="off"  value="<?php echo $ville ?>"></label>
 					<label >tel:
 			   <input type="text" name="tel"class="form-control" minlength="9" maxlength="15" pattern="^(0|\+([0-9]){2,3})([0-9]){8,9}$" autocomplete="off"required value="<?php echo $tel ?>"></input>
 			   </label>
 			   <label>fax:
 					<input type="text" name="fax"class="form-control" minlength="9" maxlength="15"pattern="^(0|\+([0-9]){2,3})([0-9]){8,9}$"autocomplete="off" value="<?php echo $fax ?>"></label>
 					<label>mail:
 					<input type="text" name="mail"class="form-control"minlength="11" maxlength="50" pattern="^([a-zA-Z]){1}([\w.])*(@gmail\.com){1}$"  autocomplete="off"required value="<?php echo $mail ?>"></label><br>
                <div class="err">
                	<?php 
                	if(isset($_POST['sub3']))
                     require("updateCompagnie.php");
                	?>
                </div>	
 					<button type="reset" name="reset"class="btn btn-danger" >
 						<i class="fa fa-remove"></i> &nbsp reset
 					</button> 
          <button type="submit" name="sub3"class="btn btn-success" >
            <i class="fa fa-save"></i> &nbsp Enregistrer
          </button>&nbsp &nbsp
 					<a href="javaScript:history.back()" id="rt">retour </a>
 			</div>




	    </div>
</div>

</div></div>
<?php
include 'footer.php';
?>
</body>
</html>