<?php
 require_once("identifier.php");
 require_once('connexiondb.php');
 require_once('myfunction.php');
$login=isset($_POST['login'])?$_POST['login']:""; 
 $pwd=isset($_POST['pwd'])?$_POST['pwd']:"";
 $email=isset($_POST['email'])?$_POST['email']:"";

 $type=0;
 $etat=0;
 if(recherche_par_login('users',$login) && recherche_par_email('users',$email))
    echo"<span class='alert alert-danger'>D&eacute;sol&eacute; le login et l'email d&eacute;ja existe!</span>";
 else if(recherche_par_login('users',$login))
     echo'<span class="alert alert-danger">D&eacute;sol&eacute; le login d&eacute;ja existe!</span>';
 else if(recherche_par_email('users',$email))
     echo"<span class='alert alert-danger'>D&eacute;sol&eacute; l'email d&eacute;ja existe</span>"; 
else {
  $sql="INSERT INTO users(login,pwd,email,type,etat) values('$login','$pwd','$email','$type','$etat')";
$res=mysqli_query($conn,$sql);
if($res){
	echo"<span class='alert alert-success'>donn&eacute;es inser&eacute;es.</span>";
     echo '<script> setTimeout(function(){
        window.location.href="utilisateur.php?"},1000); </script>';
}
else {
	echo"erreur";
}
}  
?>