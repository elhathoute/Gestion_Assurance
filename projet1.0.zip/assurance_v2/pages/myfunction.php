<?php
require_once("identifier.php");
require_once('connexiondb.php');
 function recherche_par_email($table,$email){
   $email=strtoupper($email);
    global $conn;
    $req="SELECT * from $table where UPPER(email)='$email'";
    $res=mysqli_query($conn,$req);
    $ex=mysqli_num_rows($res)>0?true:false;
    return $ex;
 }
 function recherche_par_login($table,$login){
    global $conn;
    $login=strtoupper($login);
    $req="SELECT * from $table where UPPER(login)='$login'";
    $res=mysqli_query($conn,$req);
    $ex=mysqli_num_rows($res)>0?true:false;
    return $ex;
 }
 function recherche_par_matricule($table,$matr){
    global $conn;
    $matr=strtoupper($matr);
    $req="SELECT * from $table where UPPER(matricule)='$matr'";
    $res=mysqli_query($conn,$req);
    $ex=mysqli_num_rows($res)>0?true:false;
    return $ex;
 }
 function recherche_par_CIN($table,$CIN){
    global $conn;
    $CIN=strtoupper($CIN);
    $req="SELECT * from $table where UPPER(CIN)='$CIN'";
    $res=mysqli_query($conn,$req);
    $ex=mysqli_num_rows($res)>0?true:false;
    return $ex;
 }
  function recherche_par_police($table,$police){
    global $conn;
    $police=strtoupper($police);
    $req="SELECT * from $table where UPPER(police)='$police'";
    $res=mysqli_query($conn,$req);
    $ex=mysqli_num_rows($res)>0?true:false;
    return $ex;
 }
function recherche_par_ref($table,$ref){
    global $conn;
    $ref=strtoupper($ref);
    $req="SELECT * from $table where UPPER(ref)='$ref'";
    $res=mysqli_query($conn,$req);
    $ex=mysqli_num_rows($res)>0?true:false;
    return $ex;
 }
 