<?php

require_once("identifier.php");

require_once('connexiondb.php');

$id=isset($_POST['id'])?$_POST['id']:0;
 $datea=isset($_POST['datea'])?$_POST['datea']:"";
 $timea=isset($_POST['timea'])?$_POST['timea']:"";
 $compagnie=isset($_POST['cmp'])?$_POST['cmp']:0;
 $police=isset($_POST['police'])?$_POST['police']:"";
 $numAttest=isset($_POST['numAttest'])?$_POST['numAttest']:0;
 $type=isset($_POST['type'])?$_POST['type']:0;
 $ferme=isset($_POST['ferme'])?$_POST['ferme']:0;
 $client=isset($_POST['clt'])?$_POST['clt']:0;
 $risque=isset($_POST['risque'])?$_POST['risque']:0;
 $production=isset($_POST['production'])?$_POST['production']:0;
 $nbrFractions=isset($_POST['nbrFractions'])?$_POST['nbrFractions']:0;
 $duree=isset($_POST['duree'])?$_POST['duree']:"";
 $datei=isset($_POST['datei'])?$_POST['datei']:"";
 $datef=isset($_POST['datef'])?$_POST['datef']:"";
 $solde=isset($_POST['solde'])?$_POST['solde']:0;
 $obs=isset($_POST['obs'])?$_POST['obs']:"";
 $etat=isset($_POST['etat'])?$_POST['etat']:0;
 $op=isset($_POST['op'])?$_POST['op']:"";
 $datea=date('Y-m-d',strtotime($datea));
 $timea=date('H:i:s',strtotime($timea));
 $datei=date('Y-m-d',strtotime($datei));
 $datef=date('Y-m-d',strtotime($datef));
 $req="DELETE from fractions where affaire='$id'";
 $res=mysqli_query($conn,$req);
 
 $requete="UPDATE affaires set datea='$datea',timea='$timea',compagnie='$compagnie',police='$police',
 numAttest='$numAttest',type='$type',ferme='$ferme',client='$client',risque='$risque',production='$production',nbrFractions='$nbrFractions',duree='$duree',
 datei='$datei', datef='$datef' , solde='$production', obs='$obs', etat='$etat', op='$op' where id=$id ";

 $resultat=mysqli_query($conn,$requete);
 
 $a=$duree/$nbrFractions;
    $a=floor($a*30);
    for($x=1,$n=0;$x<=$nbrFractions;$x++,$n+=$a){
      $affaire=$id;
      $montant = $solde/$nbrFractions;
      $dat=$datei."+".$n." days";
      $date_effet=date('Y-m-d',strtotime($dat));
      $requete1="INSERT into fractions (affaire,montant,date_effet,solde)
      values ('$affaire','$montant','$date_effet','$montant')";
     
      $resultat1=mysqli_query($conn,$requete1);
  }
 header('location:affaires.php');


?>