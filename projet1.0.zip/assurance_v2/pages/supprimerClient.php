
<?php

require_once("identifier.php");


require_once('connexiondb.php');
$id=isset($_GET['id'])?$_GET['id']:0;
$req="SELECT * from affaires where client=$id";
$res=mysqli_query($conn,$req);
$req1="SELECT * from clients where id=$id";
$res1=mysqli_query($conn,$req1);
$client=mysqli_fetch_assoc($res1);
if(mysqli_num_rows($res)<1){

$requete="delete from clients WHERE id=$id";
$resultat=mysqli_query($conn,$requete);

if($resultat){
  echo 'ss '.$id;
  header('location:clients.php');
}
else  echo "erreur".mysqli_error($conn);
}
else {
  echo 'impossible de supprimer ce client car il a des <a href="affaires.php?client='.$client["cin"].'"> affaires </a>: ';
 while ($aff=mysqli_fetch_assoc($res)) {
   echo '<br> id : '.$aff['id'].' / numAttest : '.$aff['numAttest'];
 }
  echo '<br> <a href="clients.php"> retour </a>';
}
?>