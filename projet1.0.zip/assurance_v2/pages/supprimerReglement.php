<?php
require_once("identifier.php");

require_once('connexiondb.php');
 $id=isset($_GET['id'])?$_GET['id']:0;
 $idA=isset($_GET['idA'])?$_GET['idA']:0;
 $req1="SELECT reglement.id as'idR',reglement.montant as'montant',fractions.id as'idF',fractions.solde as'solde', affaires.id as'idA',affaires.solde as'soldeA',affaires.production as'production' from reglement,fractions,affaires where (reglement.fraction=fractions.id and affaires.id=fractions.affaire) and reglement.id=$id";
 $res1=mysqli_query($conn,$req1);
 $reg=mysqli_fetch_assoc($res1);
 $requete="delete from reglement  WHERE id=$id";
 $resultat=mysqli_query($conn,$requete);
 $nSoldeF=$reg['solde']+$reg['montant'];
 $nSoldeA=$reg['soldeA']+$reg['montant'];

 $idF=$reg["idF"];
 $req="UPDATE fractions set solde='$nSoldeF',date_reg=null where id='$idF'";
 $res=mysqli_query($conn,$req);
 $req2="UPDATE affaires set solde='$nSoldeA' where id='$idA'";
 $res2=mysqli_query($conn,$req2);
 
 echo '<script> window.location.href="reglerAffaire.php?id='.$idA.'"; </script>';

?>