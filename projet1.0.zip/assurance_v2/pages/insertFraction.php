<?php
require_once("identifier.php");

require_once('connexiondb.php');

 $affaire=isset($_POST['affaire'])?$_POST['affaire']:"";
 $montant=isset($_POST['montant'])?$_POST['montant']:"";
 $date_effet=isset($_POST['date_effet'])?$_POST['date_effet']:"";
 $date_reg=isset($_POST['date_reg'])?$_POST['date_reg']:"";
 $solde=isset($_POST['solde'])?$_POST['solde']:"";

   
 $requete="insert into fractions (affaire,montant,date_effet,date_reg,solde)
 values ('$affaire','$montant','$date_effet','$date_reg','$solde')";
 $resultat=mysqli_query($conn,$requete);

 header('location:fractions.php');


?>