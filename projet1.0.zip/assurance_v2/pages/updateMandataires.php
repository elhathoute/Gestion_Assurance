
<?php
require_once("identifier.php");

require_once('connexiondb.php');

 $id=isset($_POST['id'])?$_POST['id']:0;
 $nom=isset($_POST['nom'])?$_POST['nom']:"";
 $cin=isset($_POST['cin'])?$_POST['cin']:"";
 $adresse=isset($_POST['adresse'])?$_POST['adresse']:"";
 $ville=isset($_POST['ville'])?$_POST['ville']:"";
 $cp=isset($_POST['cp'])?$_POST['cp']:"";
 $tel=isset($_POST['tel'])?$_POST['tel']:"";
 $ice=isset($_POST['ice'])?$_POST['ice']:"";
 $mail=isset($_POST['mail'])?$_POST['mail']:"";
 $activite=isset($_POST['activite'])?$_POST['activite']:"";
 $obs=isset($_POST['obs'])?$_POST['obs']:"";
   
 $requete="update mandataires set nom='$nom',cin='$cin',adresse='$adresse',
 ville='$ville',cp='$cp',tel='$tel',ice='$ice',mail='$mail',activite='$activite',obs='$obs' where id=$id ";


 $resultat=mysqli_query($conn,$requete);
     

 header('location:mandataires.php');
?>