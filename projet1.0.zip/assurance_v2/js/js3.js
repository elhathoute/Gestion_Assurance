

$(document).ready(function() {
  var src1="../images/charg9.gif";
	
    $("#iconn2").click(function() {
    	
	if($("#pass1").attr("type")=="password"){
	$("#pass1").attr("type","text");
	$("#iconn2>i").attr("class","fa fa-eye fa-3x");
}
   else {
   	$("#pass1").attr("type","password");
   	$("#iconn2>i").attr("class","fa fa-eye-slash fa-3x");
   }
});
// $("body").dblclick(function() {
//   $(".toggle").toggle(1000);
// });
  
 $("#prod").keyup(function(){
   $("#solde").val($(this).val());
 });
 $("#cin01").keyup(function() {

   var cin=$("#cin01").val();

 $.ajax({
    "url":"affAjax.php",
    "method":"post",
    "data":{
      cin: cin
    },
    success:function(res){
      
        $("#select").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#select").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    });
 });
 $("#aff1").keyup(function() {

   var input=$("#aff1").val();

 $.ajax({
    "url":"affaireAjax.php",
    "method":"GET",
    "data":{
      client: input
    },
    success:function(res){
      
        $("#aff2").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#aff2").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    });
 });
 $("#aff02").keyup(function() {

   var input=$("#aff02").val();

 $.ajax({
    "url":"regAjax.php",
    "method":"GET",
    "data":{
      affaire: input
    },
    success:function(res){
      
        $("#aff2").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#aff2").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    });
 });
 $("#dureeR").change(function() {

   var dureeR=$("#dureeR").val();
  
 $.ajax({
    "url":"renouvellementAjax.php",
    "method":"GET",
    "data":{
      dureeR: dureeR
    },
    success:function(res){
      
        $("#renou01").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#renou01").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    });
 });
 $("#fract").keyup(function() {

   var input=$("#fract").val();

 $.ajax({
    "url":"ajaxFraction.php",
    "method":"post",
    "data":{
      fraction: input
    },
    success:function(res){
      
        $("#fraction2").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#fraction2").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    });
 });


$(".date1").change(function() {

   var duree=$("#duree").val();
    var datei=$("#datei").val();
 $.ajax({
    "url":"date.php",
    "method":"post",
    "data":{
      duree: duree,
      datei: datei
    },
    success:function(res){
      
        $(".datef").val(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#datef").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    }); 
});

$("#matricule").keyup(function() {
 
   var mat= $("#matricule").val();

 $.ajax({
    "url":"veh.php",
    "method":"post",
    "data":{
      matricule:mat
    },
    success:function(res){
      
        $("#risque1").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#risque1").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    }); 
});

$("#loginU").keyup(function() {
 
   var login= $("#loginU").val();
    var type= $("#type1").val();
 $.ajax({
    "url":"userAjax.php",
    "method":"post",
    "data":{
      loginU:login,
       type:type
    },
    success:function(res){
      
        $("#us2").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#us2").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    });
});

$("#user").change(function() {
   var login= $("#loginU").val();
    var type= $("#type1").val();
 $.ajax({
    "url":"userAjax.php",
    "method":"post",
    "data":{
      loginU:login,
      type:type
    },
    success:function(res){
      
        $("#us2").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#us2").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    });
});
$("#nameC").keyup(function() {
 
   var name= $("#nameC").val();
 $.ajax({
    "url":"CompagnieAjax.php",
    "method":"post",
    "data":{
      nameC:name
    },
    success:function(res){
      
        $("#resC").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#resC").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    });
});
$("#tel").keyup(function() {
 
   var tel= $("#tel").val();
 $.ajax({
    "url":"CompagnieAjax.php",
    "method":"post",
    "data":{
      tel:tel
    },
    success:function(res){
      
        $("#resC").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#resC").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    });
});
$("#cin1").keyup(function() {
 
    var cin= $("#cin1").val();
 $.ajax({
    "url":"clientAjax.php",
    "method":"post",
    "data":{
      cin:cin
    },
    success:function(res){
      
        $("#res2").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#res2").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    });
});
$("#cin2").keyup(function() {
 
    var cin= $("#cin2").val();
 $.ajax({
    "url":"mandaAjax.php",
    "method":"post",
    "data":{
      cin:cin
    },
    success:function(res){
      
        $("#res2").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    },
    beforeSend:function(){
      $("#res2").html('<img src="../images/charg9.gif" style="height:160px;width:160px;margin-left:43%;">');
    }
    });
});
$(".CIN").keyup(function() {
    var cin= $(".CIN").val();
    var table=$(".CIN").attr('id');
 $.ajax({
    "url":"cinAjax.php",
    "method":"post",
    "data":{
      table:table,
      cin:cin
    },
    success:function(res){
        $("#ERR").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    }
    });
});
$(".email").keyup(function() {
    var email= $(".email").val();
    var table=$(".email").attr('id');
 $.ajax({
    "url":"emailAjax.php",
    "method":"post",
    "data":{
      table:table,
      email:email
    },
    success:function(res){
        $("#ERR").html(res);

    },
    error:function(err){
      alert("error message is :"+err);
    }
    });
});


$("#cltcmp").change(function(){
    if($(".default").is(':selected')){
     $("#hide1").hide();
    }
    else
      $('#hide1').show();
  });
var marque=["Abarth","AcAcura","Aixam","Alfa RomeoAlke","Allard","Alpina","Alpine","Alvis","AMCAmilcar","ArashAriel","AROAshok Leyland","Aston Martin","Auburn","Audi","Austin","Austin Healey","Auto Union","Autobianchi","AvtoGAZ",
"AvtoVAZ","Bellier","Bentley","BMW","Bolloré","Bristol","Bugatti","Buick","Cadillac","Casalini","Caterham","Chatenet","Chausson","Chenard et Walcker","Chevrolet","Chrysler","Citroën","Dacia","Daewoo","Daihatsu","Datsun","De Dion-Bouton",
"De Tomaso","Delage","Delahaye","DeLorean","Dodge","Donkervoort","DSDué","Eagle","Exagon","Excalibur","Facel Vega","Ferrari","FIAT",
"Fisker","Ford","Ford Mustang","FusoGAZ","Ginetta","GMCGrecav","Gumpert","Hispano Suiza","Hommell","Honda","Horch","Hummer","Hyundai","Infiniti","Innocenti","Isuzu","Iveco","Jaguar","JDM Simpa","Jeep","Karma","Kia",
"Koenigsegg","KTMLada","Lamborghini","Lancia","Land Rover","Lexus","Ligier","Lincoln","Lotus","Maserati","Matra","Maybach","Mazda","McLaren","Mega","Mercedes-Benz","MGMia electric","Mini","Mitsubishi","Mitsuoka",
"Monica","Morgan","Morris","Nash","Neckar","Nissan","Noble","NSU","Oldsmobile","Opel","Packard","Pagani","Panhard","Panoz","Panther","Peugeot","PGOPlymouth","Pontiac","Porsche","Radical","Renault","Riley",
"Rolls-Royce","Rover","Saab","Saleen","Santana","Seat","Secma","Shelby","Simca","Skoda","Smart","SsangYong","Studebaker","Subaru","Suzuki",
"Talbot","Tata","Tazzari","Tesla Motors","Toyota","Triumph","Tvr","Ultima","VAZ","Vector","Venturi","Volkswagen","Volvo","Weber","Wiesmann","Wolseley","Zastava","Zenvo"
];

$('#veh').submit(function(e){
  var marque1 = $("#marque").val();
  if(marque.indexOf(marque1)!=-1){
  $("#marque").css({
    'border': "green",
   'box-shadow': "2px 2px 5px 2px green"
  });
  $("#errM").html("");
}
else {
  $("#marque").css({
   'border': "red",
   'box-shadow': "2px 2px 5px 2px red"
 });
  $("#errM").html("veuillez entrer une marque valide!");
  e.preventDefault();
}
});

var pays=["Afrique du Sud","Afghanistan","Albanie","Algérie","Allemagne","Andorre","Angola ",
"Antigua-et-Barbuda","Arabie Saoudite","Argentine","Arménie","Australie","Autriche","Azerbaïdjan",
"Bahamas","Bahreïn","Bangladesh","Barbade","Belgique","Belize","Bénin","Bhoutan","Biélorussie",
"Birmanie","Bolivie","Cameroun","Canada","Chine","Colombie","Côte d’Ivoire","Danemark","Égypte",
"Espagne","États-Unis","France","Inde","Indonésie","Irak","Iran","Italie","Japon","Koweït","Libye",
"Maroc","Nigeria","Niger","Palestine","Qatar","Portugal","Russie","Soudan","Suisse"]
$("#marque").autocomplete({
  source:marque,
});
$("#pays").autocomplete({
  source:pays,
});
});
function reglerAff(idA){
   window.location.href="reglerAffaire.php?id="+idA;
}
function editObsF(idF){
   window.location.href="editObsF.php?id="+idF;
}
function editObsA(idA){
   window.location.href="editObsA.php?id="+idA;
}

























